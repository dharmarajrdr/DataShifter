import React, { useState } from 'react';
import { COLORS, FONT, SPACING, BORDER_RADIUS } from '../../constants/design';
import { FRSC, FRBC, FREC } from '../../constants/layouts';
import { Button } from '../common';
import { CloseIcon } from '../layout/Icons';

const DB_TYPES = [
  { value: 'ORACLE', label: 'Oracle', defaultPort: 1521 },
  { value: 'SPANNER', label: 'Google Cloud Spanner', defaultPort: null },
];

const INITIAL = {
  name: '', dbType: 'ORACLE', dbVersion: '', host: '', port: 1521,
  databaseName: '', schemaName: '', username: '', password: '', extraProperties: '',
};

const Field = ({ label, children, hint }) => (
  <div style={{ marginBottom: SPACING.sm }}>
    <label style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, display: 'block', marginBottom: SPACING.xxs }}>{label}</label>
    {children}
    {hint && <p style={{ fontSize: '10px', color: COLORS.text.tertiary, marginTop: '2px' }}>{hint}</p>}
  </div>
);

const inputStyle = {
  width: '100%', padding: `${SPACING.xs} 10px`, border: `1px solid ${COLORS.border.light}`,
  borderRadius: BORDER_RADIUS.md, fontSize: FONT.size.md, boxSizing: 'border-box',
  background: COLORS.background.primary,
};

const ConnectionFormModal = ({ connection, onClose, onSave }) => {
  const isEdit = !!connection;
  const [form, setForm] = useState(isEdit ? {
    name: connection.name || '', dbType: connection.dbType || 'ORACLE',
    dbVersion: connection.dbVersion || '', host: connection.host || '',
    port: connection.port || 1521, databaseName: connection.databaseName || connection.schema || '',
    schemaName: connection.schemaName || connection.schema || '',
    username: '', password: '', extraProperties: '',
  } : { ...INITIAL });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const set = (key, val) => setForm(prev => ({ ...prev, [key]: val }));

  const handleDbTypeChange = (dbType) => {
    const def = DB_TYPES.find(d => d.value === dbType);
    set('dbType', dbType);
    if (def && def.defaultPort) set('port', def.defaultPort);
  };

  const handleSubmit = async () => {
    if (!form.name || !form.host) { setError('Name and host are required'); return; }
    setSaving(true);
    setError(null);
    try {
      await onSave(form);
      onClose();
    } catch (e) {
      setError(e.message || 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const isSpanner = form.dbType === 'SPANNER';

  return (
    <div style={{
      position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
      background: 'rgba(0,0,0,0.35)', display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 1000,
    }} onClick={onClose}>
      <div style={{
        background: COLORS.background.primary, borderRadius: BORDER_RADIUS.lg,
        width: '520px', maxHeight: '85vh', overflow: 'auto',
        border: `1px solid ${COLORS.border.light}`,
      }} onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div style={{ ...FRBC, padding: `${SPACING.md} ${SPACING.lg}`, borderBottom: `1px solid ${COLORS.border.light}` }}>
          <p style={{ fontSize: FONT.size.lg, fontWeight: FONT.weight.medium }}>
            {isEdit ? 'Edit connection' : 'New connection'}
          </p>
          <span onClick={onClose} style={{ cursor: 'pointer' }}><CloseIcon /></span>
        </div>

        <div style={{ padding: SPACING.lg }}>
          {/* DB Type selector */}
          <Field label="Database type">
            <div style={{ ...FRSC, gap: SPACING.xs }}>
              {DB_TYPES.map(db => (
                <div key={db.value} onClick={() => handleDbTypeChange(db.value)} style={{
                  flex: 1, padding: SPACING.sm, textAlign: 'center', cursor: 'pointer',
                  border: form.dbType === db.value ? `2px solid ${COLORS.brand.primary}` : `1px solid ${COLORS.border.light}`,
                  borderRadius: BORDER_RADIUS.md,
                  background: form.dbType === db.value ? COLORS.accent.purpleLight : COLORS.background.primary,
                }}>
                  <p style={{ fontSize: FONT.size.sm, fontWeight: FONT.weight.medium,
                    color: form.dbType === db.value ? COLORS.accent.purpleText : COLORS.text.primary }}>{db.label}</p>
                </div>
              ))}
            </div>
          </Field>

          <Field label="Connection name">
            <input value={form.name} onChange={e => set('name', e.target.value)} style={inputStyle} placeholder="e.g., Oracle production" />
          </Field>

          <Field label={isSpanner ? 'Instance path' : 'Host'} hint={isSpanner ? 'Format: projects/{project}/instances/{instance}' : null}>
            <input value={form.host} onChange={e => set('host', e.target.value)} style={inputStyle}
              placeholder={isSpanner ? 'projects/my-project/instances/my-instance' : 'oracle-prod.company.com'} />
          </Field>

          {!isSpanner && (
            <div style={{ ...FRSC, gap: SPACING.sm }}>
              <Field label="Port">
                <input type="number" value={form.port} onChange={e => set('port', parseInt(e.target.value) || '')}
                  style={{ ...inputStyle, width: '100px' }} />
              </Field>
              <div style={{ flex: 1 }}>
                <Field label="Database / SID">
                  <input value={form.databaseName} onChange={e => set('databaseName', e.target.value)} style={inputStyle} placeholder="ORCL" />
                </Field>
              </div>
            </div>
          )}

          {isSpanner ? (
            <Field label="Database name">
              <input value={form.databaseName} onChange={e => set('databaseName', e.target.value)} style={inputStyle} placeholder="orders-db" />
            </Field>
          ) : (
            <Field label="Schema">
              <input value={form.schemaName} onChange={e => set('schemaName', e.target.value)} style={inputStyle} placeholder="PROD_SCHEMA" />
            </Field>
          )}

          {!isSpanner && (
            <>
              <Field label="Username">
                <input value={form.username} onChange={e => set('username', e.target.value)} style={inputStyle} placeholder="db_user" />
              </Field>
              <Field label="Password">
                <input type="password" value={form.password} onChange={e => set('password', e.target.value)} style={inputStyle}
                  placeholder={isEdit ? '(leave blank to keep current)' : 'Enter password'} />
              </Field>
            </>
          )}

          {isSpanner && (
            <Field label="Service account JSON key" hint="Paste the full JSON key or leave blank for Application Default Credentials">
              <textarea value={form.password} onChange={e => set('password', e.target.value)}
                rows={3} style={{ ...inputStyle, resize: 'vertical', fontFamily: 'monospace', fontSize: FONT.size.xs }}
                placeholder='{"type": "service_account", ...}' />
            </Field>
          )}

          {error && (
            <div style={{ background: COLORS.status.errorLight, color: COLORS.status.errorText,
              padding: `${SPACING.xs} ${SPACING.sm}`, borderRadius: BORDER_RADIUS.md, fontSize: FONT.size.xs, marginBottom: SPACING.sm }}>
              {error}
            </div>
          )}

          <div style={{ ...FREC, gap: SPACING.xs, paddingTop: SPACING.sm, borderTop: `1px solid ${COLORS.border.light}` }}>
            <Button variant="secondary" onClick={onClose}>Cancel</Button>
            <Button onClick={handleSubmit} style={saving ? { opacity: 0.6 } : {}}>
              {saving ? 'Saving...' : (isEdit ? 'Update connection' : 'Create connection')}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConnectionFormModal;