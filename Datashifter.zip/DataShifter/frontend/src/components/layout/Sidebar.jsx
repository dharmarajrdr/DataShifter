import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { COLORS, FONT, SPACING, BORDER_RADIUS, SIDEBAR_WIDTH } from '../../constants/design';
import { FCSS, FRSC } from '../../constants/layouts';
import { APP, NAV } from '../../constants/literals';
import { PipelineIcon, ConnectionIcon, SettingsIcon, LogoIcon } from './Icons';

const NAV_ITEMS = [
  { label: NAV.pipelines, path: '/pipelines', icon: PipelineIcon },
  { label: NAV.connections, path: '/connections', icon: ConnectionIcon },
  { label: 'Settings', path: '/settings', icon: SettingsIcon },
];

const Sidebar = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const isActive = (path) => location.pathname === path || location.pathname.startsWith(path + '/');

  return (
    <div style={{
      display: 'flex', flexDirection: 'column',
      width: SIDEBAR_WIDTH,
      background: COLORS.background.secondary,
      borderRight: `1px solid ${COLORS.border.light}`,
      padding: `${SPACING.md} 0`,
      height: '100vh',
      position: 'fixed', left: 0, top: 0, zIndex: 100,
    }}>
      {/* Logo */}
      <div style={{ ...FRSC, gap: SPACING.xs, padding: `0 ${SPACING.md}`, marginBottom: SPACING.xl, cursor: 'pointer' }}
        onClick={() => navigate('/pipelines')}>
        <LogoIcon />
        <span style={{ fontWeight: FONT.weight.semibold, fontSize: FONT.size.lg, color: COLORS.text.primary }}>
          {APP.name}
        </span>
      </div>

      {/* Main Nav */}
      <div style={{ ...FCSS, gap: '2px', padding: `0 ${SPACING.xs}`, alignItems: 'stretch' }}>
        {NAV_ITEMS.map(item => {
          const active = isActive(item.path);
          const Icon = item.icon;
          return (
            <div key={item.path}
              onClick={() => navigate(item.path === '/settings' ? '/settings/org' : item.path)}
              style={{
                ...FRSC, gap: SPACING.xs,
                padding: `${SPACING.xs} ${SPACING.sm}`, borderRadius: BORDER_RADIUS.md,
                background: active ? COLORS.accent.purpleLight : 'transparent',
                color: active ? COLORS.accent.purpleText : COLORS.text.secondary,
                fontSize: FONT.size.md,
                fontWeight: active ? FONT.weight.medium : FONT.weight.regular,
                cursor: 'pointer', transition: 'background 0.15s ease',
              }}
              onMouseEnter={e => { if (!active) e.currentTarget.style.background = COLORS.background.tertiary; }}
              onMouseLeave={e => { if (!active) e.currentTarget.style.background = 'transparent'; }}
            >
              <Icon color={active ? COLORS.accent.purpleText : COLORS.text.secondary} size={16} />
              {item.label}
            </div>
          );
        })}
      </div>

      {/* Spacer */}
      <div style={{ flex: 1 }} />

      {/* Profile */}
      <div style={{ padding: `0 ${SPACING.xs}`, borderTop: `1px solid ${COLORS.border.light}`, paddingTop: SPACING.sm }}>
        <div onClick={() => navigate('/profile')}
          style={{
            ...FRSC, gap: SPACING.xs,
            padding: `${SPACING.xs} ${SPACING.sm}`, borderRadius: BORDER_RADIUS.md,
            background: isActive('/profile') ? COLORS.accent.purpleLight : 'transparent',
            cursor: 'pointer', transition: 'background 0.15s ease',
          }}
          onMouseEnter={e => { if (!isActive('/profile')) e.currentTarget.style.background = COLORS.background.tertiary; }}
          onMouseLeave={e => { if (!isActive('/profile')) e.currentTarget.style.background = 'transparent'; }}
        >
          <div style={{
            width: 28, height: 28, borderRadius: '50%', background: COLORS.brand.primary,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: FONT.size.xs, fontWeight: 500, color: '#fff', flexShrink: 0,
          }}>DR</div>
          <div style={{ minWidth: 0 }}>
            <p style={{
              fontSize: FONT.size.sm, fontWeight: FONT.weight.medium,
              color: isActive('/profile') ? COLORS.accent.purpleText : COLORS.text.primary,
              whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
              lineHeight: 1.3, margin: 0,
            }}>Dharmaraj R</p>
            <p style={{ fontSize: '10px', color: COLORS.text.tertiary, lineHeight: 1.3, margin: 0 }}>Admin</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;