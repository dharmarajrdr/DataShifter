import React, { useState, useRef, useCallback, useEffect } from 'react';
import { COLORS, FONT, SPACING, BORDER_RADIUS } from '../../constants/design';

/* ================================================================
   COLOR PALETTE for mapping lines — cycles through these
   ================================================================ */
const LINE_COLORS = [
  { stroke: '#534AB7', bg: '#EEEDFE', text: '#3C3489', key: 'purple' },
  { stroke: '#1D9E75', bg: '#E1F5EE', text: '#085041', key: 'teal' },
  { stroke: '#D85A30', bg: '#FAECE7', text: '#712B13', key: 'coral' },
  { stroke: '#D4537E', bg: '#FBEAF0', text: '#72243E', key: 'pink' },
  { stroke: '#378ADD', bg: '#E6F1FB', text: '#0C447C', key: 'blue' },
];

/* ================================================================
   COLUMN PANEL — renders one side (source or target) with dots
   ================================================================ */
const COL_ROW_HEIGHT = 36;
const HEADER_HEIGHT = 40;
const PANEL_WIDTH = 240;
const DOT_RADIUS = 6;

const ColumnPanel = ({ title, titleBg, titleColor, columns, side, panelRef, onDotMouseDown, onDotMouseUp, mappedCols, selectedMapping }) => {

  const getDotColor = (colName) => {
    const m = mappedCols.find(mc => mc.col === colName);
    return m ? m.color : COLORS.border.medium;
  };

  const isMapped = (colName) => mappedCols.some(mc => mc.col === colName);

  return (
    <div ref={panelRef} style={{
      width: PANEL_WIDTH, background: COLORS.background.primary,
      border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.lg,
      overflow: 'hidden', flexShrink: 0, userSelect: 'none',
    }}>
      <div style={{ background: titleBg, padding: `10px ${SPACING.md}`, height: HEADER_HEIGHT, display: 'flex', alignItems: 'center' }}>
        <span style={{ fontSize: FONT.size.md, fontWeight: FONT.weight.medium, color: titleColor }}>{title}</span>
      </div>
      {columns.map((col, i) => (
        <div
          key={col.name}
          data-col={col.name}
          data-side={side}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: `0 ${SPACING.md}`, height: COL_ROW_HEIGHT,
            fontSize: FONT.size.sm, opacity: isMapped(col.name) ? 1 : 0.5,
            background: selectedMapping && (selectedMapping.source === col.name || selectedMapping.target === col.name)
              ? COLORS.accent.purpleLight : 'transparent',
            transition: 'background 0.15s',
          }}
        >
          {side === 'source' ? (
            <>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ color: COLORS.text.primary }}>{col.name}</span>
                <span style={{ background: COLORS.background.secondary, padding: '1px 6px', borderRadius: 4, fontSize: 10, color: COLORS.text.secondary }}>{col.type}</span>
              </div>
              <div
                data-dot={`src-${col.name}`}
                onMouseDown={(e) => onDotMouseDown(e, col.name, 'source')}
                style={{
                  width: DOT_RADIUS * 2, height: DOT_RADIUS * 2, borderRadius: '50%',
                  background: getDotColor(col.name),
                  cursor: 'crosshair', flexShrink: 0,
                  border: `2px solid ${getDotColor(col.name)}`,
                  transition: 'transform 0.1s',
                }}
                onMouseEnter={e => e.target.style.transform = 'scale(1.4)'}
                onMouseLeave={e => e.target.style.transform = 'scale(1)'}
              />
            </>
          ) : (
            <>
              <div
                data-dot={`tgt-${col.name}`}
                onMouseUp={(e) => onDotMouseUp(e, col.name, 'target')}
                onMouseDown={(e) => onDotMouseDown(e, col.name, 'target')}
                style={{
                  width: DOT_RADIUS * 2, height: DOT_RADIUS * 2, borderRadius: '50%',
                  background: getDotColor(col.name),
                  cursor: 'crosshair', flexShrink: 0,
                  border: `2px solid ${getDotColor(col.name)}`,
                  transition: 'transform 0.1s',
                }}
                onMouseEnter={e => e.target.style.transform = 'scale(1.4)'}
                onMouseLeave={e => e.target.style.transform = 'scale(1)'}
              />
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ color: COLORS.text.primary }}>{col.name}</span>
                <span style={{ background: COLORS.background.secondary, padding: '1px 6px', borderRadius: 4, fontSize: 10, color: COLORS.text.secondary }}>{col.type}</span>
              </div>
            </>
          )}
        </div>
      ))}
    </div>
  );
};

/* ================================================================
   MAIN COMPONENT — DragMappingBoard
   ================================================================ */
const DragMappingBoard = ({
  sourceColumns,     // [{ name, type }]
  targetColumns,     // [{ name, type }]
  mappings,          // [{ source, target, color, transforms }]
  onMappingsChange,  // (newMappings) => void
  onMappingClick,    // (mapping) => void — e.g., open transform builder
  sourceTable,
  targetTable,
}) => {
  const containerRef = useRef(null);
  const sourcePanelRef = useRef(null);
  const targetPanelRef = useRef(null);
  const [dragging, setDragging] = useState(null); // { fromCol, fromSide, startX, startY, currentX, currentY }
  const [selectedIdx, setSelectedIdx] = useState(null);
  const [dotPositions, setDotPositions] = useState({ source: {}, target: {} });

  /* --- Compute dot positions relative to container --- */
  const computeDotPositions = useCallback(() => {
    if (!containerRef.current || !sourcePanelRef.current || !targetPanelRef.current) return;
    const containerRect = containerRef.current.getBoundingClientRect();
    const src = {};
    const tgt = {};

    sourcePanelRef.current.querySelectorAll('[data-dot]').forEach(el => {
      const r = el.getBoundingClientRect();
      const colName = el.dataset.dot.replace('src-', '');
      src[colName] = { x: r.left + r.width / 2 - containerRect.left, y: r.top + r.height / 2 - containerRect.top };
    });

    targetPanelRef.current.querySelectorAll('[data-dot]').forEach(el => {
      const r = el.getBoundingClientRect();
      const colName = el.dataset.dot.replace('tgt-', '');
      tgt[colName] = { x: r.left + r.width / 2 - containerRect.left, y: r.top + r.height / 2 - containerRect.top };
    });

    setDotPositions({ source: src, target: tgt });
  }, [sourceColumns, targetColumns]);

  useEffect(() => {
    computeDotPositions();
    window.addEventListener('resize', computeDotPositions);
    return () => window.removeEventListener('resize', computeDotPositions);
  }, [computeDotPositions]);

  // Recompute after render (panels need to be mounted)
  useEffect(() => {
    const timer = setTimeout(computeDotPositions, 50);
    return () => clearTimeout(timer);
  }, [mappings, computeDotPositions]);

  /* --- Drag handlers --- */
  const onDotMouseDown = useCallback((e, colName, side) => {
    e.preventDefault();
    const containerRect = containerRef.current.getBoundingClientRect();
    const pos = dotPositions[side][colName];
    if (!pos) return;
    setDragging({
      fromCol: colName, fromSide: side,
      startX: pos.x, startY: pos.y,
      currentX: e.clientX - containerRect.left,
      currentY: e.clientY - containerRect.top,
    });
    setSelectedIdx(null);
  }, [dotPositions]);

  const onMouseMove = useCallback((e) => {
    if (!dragging) return;
    const containerRect = containerRef.current.getBoundingClientRect();
    setDragging(prev => ({
      ...prev,
      currentX: e.clientX - containerRect.left,
      currentY: e.clientY - containerRect.top,
    }));
  }, [dragging]);

  const onDotMouseUp = useCallback((e, colName, side) => {
    if (!dragging) return;
    // Must connect source → target (either direction of drag)
    let srcCol, tgtCol;
    if (dragging.fromSide === 'source' && side === 'target') {
      srcCol = dragging.fromCol; tgtCol = colName;
    } else if (dragging.fromSide === 'target' && side === 'source') {
      srcCol = colName; tgtCol = dragging.fromCol;
    } else {
      setDragging(null);
      return; // same-side connection not allowed
    }

    // Check if this mapping already exists
    const exists = mappings.some(m => m.source === srcCol && m.target === tgtCol);
    if (!exists) {
      const colorIdx = mappings.length % LINE_COLORS.length;
      const newMapping = {
        source: srcCol, target: tgtCol,
        color: LINE_COLORS[colorIdx].key,
        transforms: [],
      };
      onMappingsChange([...mappings, newMapping]);
    }
    setDragging(null);
  }, [dragging, mappings, onMappingsChange]);

  const onMouseUp = useCallback(() => {
    setDragging(null);
  }, []);

  /* --- Delete selected mapping --- */
  const deleteSelected = useCallback(() => {
    if (selectedIdx === null) return;
    const newMappings = mappings.filter((_, i) => i !== selectedIdx);
    onMappingsChange(newMappings);
    setSelectedIdx(null);
  }, [selectedIdx, mappings, onMappingsChange]);

  useEffect(() => {
    const handleKey = (e) => {
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedIdx !== null) {
        deleteSelected();
      }
      if (e.key === 'Escape') setSelectedIdx(null);
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [deleteSelected, selectedIdx]);

  /* --- Build bezier path between two points --- */
  const bezierPath = (x1, y1, x2, y2) => {
    const dx = Math.abs(x2 - x1) * 0.5;
    return `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`;
  };

  /* --- Resolve color for a mapping --- */
  const getLineColor = (mapping) => {
    return LINE_COLORS.find(c => c.key === mapping.color) || LINE_COLORS[0];
  };

  /* --- Mapped column lookup for dot coloring --- */
  const sourceMappedCols = mappings.map(m => ({ col: m.source, color: getLineColor(m).stroke }));
  const targetMappedCols = mappings.map(m => ({ col: m.target, color: getLineColor(m).stroke }));

  /* --- Render --- */
  return (
    <div
      ref={containerRef}
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
        padding: SPACING.lg, position: 'relative',
        background: COLORS.background.primary,
        border: `1px solid ${COLORS.border.light}`,
        borderRadius: BORDER_RADIUS.lg,
        cursor: dragging ? 'crosshair' : 'default',
        minHeight: Math.max(sourceColumns.length, targetColumns.length) * COL_ROW_HEIGHT + HEADER_HEIGHT + 60,
      }}
    >
      {/* Source panel */}
      <ColumnPanel
        title={`SOURCE: ${sourceTable}`}
        titleBg={COLORS.accent.purpleLight}
        titleColor={COLORS.accent.purpleText}
        columns={sourceColumns}
        side="source"
        panelRef={sourcePanelRef}
        onDotMouseDown={onDotMouseDown}
        onDotMouseUp={onDotMouseUp}
        mappedCols={sourceMappedCols}
        selectedMapping={selectedIdx !== null ? mappings[selectedIdx] : null}
      />

      {/* SVG overlay for connection lines */}
      <svg
        style={{
          position: 'absolute', top: 0, left: 0, width: '100%', height: '100%',
          pointerEvents: 'none', zIndex: 1,
        }}
      >
        {/* Existing mappings */}
        {mappings.map((m, i) => {
          const srcPos = dotPositions.source[m.source];
          const tgtPos = dotPositions.target[m.target];
          if (!srcPos || !tgtPos) return null;
          const lc = getLineColor(m);
          const isSelected = selectedIdx === i;

          return (
            <g key={`${m.source}-${m.target}`}>
              {/* Invisible fat line for easy click target */}
              <path
                d={bezierPath(srcPos.x, srcPos.y, tgtPos.x, tgtPos.y)}
                fill="none" stroke="transparent" strokeWidth={14}
                style={{ pointerEvents: 'stroke', cursor: 'pointer' }}
                onClick={() => {
                  setSelectedIdx(isSelected ? null : i);
                  if (onMappingClick && !isSelected) onMappingClick(m);
                }}
              />
              {/* Visible line */}
              <path
                d={bezierPath(srcPos.x, srcPos.y, tgtPos.x, tgtPos.y)}
                fill="none"
                stroke={isSelected ? lc.stroke : lc.stroke}
                strokeWidth={isSelected ? 2.5 : 1.5}
                strokeDasharray={isSelected ? 'none' : '5 3'}
                opacity={isSelected ? 1 : 0.6}
              />
              {/* Transform badge on midpoint */}
              {m.transforms.length > 0 && (() => {
                const mx = (srcPos.x + tgtPos.x) / 2;
                const my = (srcPos.y + tgtPos.y) / 2;
                const label = m.transforms.map(t => t.fn).join('→');
                const tw = Math.min(label.length * 6.5 + 16, 120);
                return (
                  <g style={{ pointerEvents: 'all', cursor: 'pointer' }}
                     onClick={() => { setSelectedIdx(i); if (onMappingClick) onMappingClick(m); }}>
                    <rect x={mx - tw / 2} y={my - 10} width={tw} height={20} rx={4}
                          fill={lc.bg} stroke={lc.stroke} strokeWidth={0.5} />
                    <text x={mx} y={my + 4} textAnchor="middle"
                          fill={lc.text} fontSize="10" fontFamily="monospace" fontWeight="500">
                      {label.length > 16 ? label.slice(0, 15) + '…' : label}
                    </text>
                  </g>
                );
              })()}
            </g>
          );
        })}

        {/* In-progress drag line */}
        {dragging && (
          <path
            d={bezierPath(dragging.startX, dragging.startY, dragging.currentX, dragging.currentY)}
            fill="none" stroke={COLORS.brand.primary} strokeWidth={2}
            strokeDasharray="6 4" opacity={0.7}
          />
        )}
      </svg>

      {/* Target panel */}
      <ColumnPanel
        title={`TARGET: ${targetTable}`}
        titleBg={COLORS.accent.tealLight}
        titleColor={COLORS.accent.tealText}
        columns={targetColumns}
        side="target"
        panelRef={targetPanelRef}
        onDotMouseDown={onDotMouseDown}
        onDotMouseUp={onDotMouseUp}
        mappedCols={targetMappedCols}
        selectedMapping={selectedIdx !== null ? mappings[selectedIdx] : null}
      />

      {/* Delete hint when a line is selected */}
      {selectedIdx !== null && (
        <div style={{
          position: 'absolute', bottom: 12, left: '50%', transform: 'translateX(-50%)',
          background: COLORS.status.errorLight, color: COLORS.status.errorText,
          padding: '6px 16px', borderRadius: BORDER_RADIUS.pill,
          fontSize: FONT.size.xs, fontWeight: FONT.weight.medium,
          zIndex: 2, display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <span>{mappings[selectedIdx].source} → {mappings[selectedIdx].target}</span>
          <span style={{ color: COLORS.text.tertiary }}>|</span>
          <span style={{ cursor: 'pointer', textDecoration: 'underline' }} onClick={deleteSelected}>
            Delete (or press ⌫)
          </span>
        </div>
      )}
    </div>
  );
};

export default DragMappingBoard;