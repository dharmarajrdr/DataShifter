import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { COLORS, FONT, SPACING, BORDER_RADIUS } from '../constants/design';
import { FRSC, FRBC, FCCC } from '../constants/layouts';
import { WIZARD } from '../constants/literals';
import { PageHeader, Button, Chip, SortableList } from '../components/common';
import { WarningIcon } from '../components/layout/Icons';
import CreateNamespaceModal from '../components/pipeline/CreateNamespaceModal';
import { MOCK_CONNECTIONS, MOCK_AVAILABLE_TABLES, namespaceApi } from '../services/api';

/* ================================================================
   STEP INDICATOR — shared across all steps
   ================================================================ */
const StepIndicator = ({ steps, currentStep }) => (
  <div style={{ ...FRSC, gap: 0, padding: `0 ${SPACING.xxl}`, marginBottom: SPACING.sm }}>
    {steps.map((step, i) => (
      <React.Fragment key={i}>
        <div style={{ ...FCCC, gap: '6px', flexShrink: 0 }}>
          <div style={{
            width: 32, height: 32, borderRadius: '50%',
            background: i <= currentStep ? COLORS.brand.primary : 'transparent',
            border: i <= currentStep ? 'none' : `2px solid ${i === currentStep + 1 ? COLORS.brand.primary : COLORS.border.medium}`,
            color: i <= currentStep ? '#fff' : (i === currentStep + 1 ? COLORS.brand.primary : COLORS.text.secondary),
            ...FCCC, fontSize: FONT.size.md, fontWeight: FONT.weight.medium,
          }}>{i + 1}</div>
          <span style={{
            fontSize: FONT.size.xs,
            fontWeight: i <= currentStep ? FONT.weight.medium : FONT.weight.regular,
            color: i <= currentStep ? COLORS.brand.primary : COLORS.text.secondary,
          }}>{step}</span>
        </div>
        {i < steps.length - 1 && (
          <div style={{
            flex: 1, height: '2px', marginBottom: '18px',
            background: i < currentStep ? COLORS.brand.primary : COLORS.border.light,
          }} />
        )}
      </React.Fragment>
    ))}
  </div>
);

/* ================================================================
   STEP 0: BASICS
   ================================================================ */
const StepBasics = ({ config, setConfig, namespaces, onCreateNamespace }) => (
  <div style={{ maxWidth: '480px' }}>
    <h3 style={{ fontSize: FONT.size.lg, fontWeight: FONT.weight.medium, marginBottom: SPACING.xxs }}>Pipeline basics</h3>
    <p style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, marginBottom: SPACING.lg }}>Give your pipeline a name, description, and assign it to a namespace.</p>
    <div style={{ marginBottom: SPACING.md }}>
      <label style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, display: 'block', marginBottom: SPACING.xxs }}>Pipeline name</label>
      <input
        value={config.name} onChange={e => setConfig({ ...config, name: e.target.value })}
        style={{ width: '100%', padding: `${SPACING.xs} 10px`, border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.md, fontSize: FONT.size.md, boxSizing: 'border-box' }}
        placeholder="e.g., Orders migration"
      />
    </div>
    <div style={{ marginBottom: SPACING.md }}>
      <label style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, display: 'block', marginBottom: SPACING.xxs }}>Description</label>
      <textarea
        value={config.description} onChange={e => setConfig({ ...config, description: e.target.value })}
        rows={3}
        style={{ width: '100%', padding: `${SPACING.xs} 10px`, border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.md, fontSize: FONT.size.md, boxSizing: 'border-box', resize: 'vertical' }}
        placeholder="Describe what this pipeline does"
      />
    </div>
    <div>
      <label style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, display: 'block', marginBottom: SPACING.xxs }}>Namespace</label>
      <div style={{ ...FRSC, gap: '6px', flexWrap: 'wrap' }}>
        {namespaces.map(ns => (
          <div
            key={ns.id}
            onClick={() => setConfig({ ...config, namespaceId: ns.id })}
            style={{
              padding: `${SPACING.xs} ${SPACING.sm}`, borderRadius: BORDER_RADIUS.md, cursor: 'pointer',
              border: config.namespaceId === ns.id ? `2px solid ${ns.color || COLORS.brand.primary}` : `1px solid ${COLORS.border.light}`,
              background: config.namespaceId === ns.id ? (ns.color || COLORS.brand.primary) + '15' : COLORS.background.primary,
              display: 'flex', alignItems: 'center', gap: '6px',
            }}
          >
            <div style={{ width: 8, height: 8, borderRadius: '2px', background: ns.color || COLORS.brand.primary }} />
            <span style={{
              fontSize: FONT.size.sm, fontWeight: config.namespaceId === ns.id ? FONT.weight.medium : FONT.weight.regular,
              color: config.namespaceId === ns.id ? (ns.color || COLORS.brand.primary) : COLORS.text.primary,
            }}>{ns.name}</span>
          </div>
        ))}
        {/* + Create namespace */}
        <div
          onClick={onCreateNamespace}
          style={{
            padding: `${SPACING.xs} ${SPACING.sm}`, borderRadius: BORDER_RADIUS.md, cursor: 'pointer',
            border: `1px dashed ${COLORS.brand.primary}`,
            background: COLORS.background.primary,
            display: 'flex', alignItems: 'center', gap: '4px',
          }}
          onMouseEnter={e => { e.currentTarget.style.background = COLORS.accent.purpleLight; }}
          onMouseLeave={e => { e.currentTarget.style.background = COLORS.background.primary; }}
        >
          <span style={{ fontSize: '14px', color: COLORS.brand.primary, lineHeight: 1 }}>+</span>
        </div>
      </div>
      <p style={{ fontSize: FONT.size.xs, color: COLORS.text.tertiary, marginTop: SPACING.xxs }}>
        Group this pipeline under a namespace. You can change this later.
      </p>
    </div>
  </div>
);

/* ================================================================
   STEP 1: CONNECTIONS
   ================================================================ */
const StepConnections = ({ config, setConfig }) => (
  <div>
    <h3 style={{ fontSize: FONT.size.lg, fontWeight: FONT.weight.medium, marginBottom: SPACING.xxs }}>Select connections</h3>
    <p style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, marginBottom: SPACING.lg }}>Choose source and target database connections.</p>
    <div style={{ ...FRSC, gap: SPACING.lg, alignItems: 'flex-start' }}>
      {['source', 'target'].map(role => (
        <div key={role} style={{ flex: 1 }}>
          <label style={{ fontSize: FONT.size.sm, fontWeight: FONT.weight.medium, color: COLORS.text.secondary, display: 'block', marginBottom: SPACING.xs, textTransform: 'capitalize' }}>{role} connection</label>
          {MOCK_CONNECTIONS.filter(c => c.status === 'CONNECTED').map(conn => (
            <div
              key={conn.id}
              onClick={() => setConfig({ ...config, [role]: conn.id })}
              style={{
                padding: SPACING.sm, borderRadius: BORDER_RADIUS.md, marginBottom: SPACING.xs,
                border: config[role] === conn.id ? `2px solid ${COLORS.brand.primary}` : `1px solid ${COLORS.border.light}`,
                background: config[role] === conn.id ? COLORS.accent.purpleLight : COLORS.background.primary,
                cursor: 'pointer',
              }}
            >
              <p style={{ fontSize: FONT.size.md, fontWeight: FONT.weight.medium, marginBottom: '2px' }}>{conn.name}</p>
              <p style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary }}>{conn.type} — {conn.host}</p>
            </div>
          ))}
        </div>
      ))}
    </div>
  </div>
);

/* ================================================================
   STEP 2: TABLES — with SortableList drag-to-reorder
   ================================================================ */
const StepTables = ({ config, setConfig }) => {
  const [search, setSearch] = useState('');
  const available = MOCK_AVAILABLE_TABLES.filter(
    t => !config.selectedTables.includes(t) && t.toLowerCase().includes(search.toLowerCase())
  );

  const addTable = (t) => setConfig({ ...config, selectedTables: [...config.selectedTables, t] });
  const removeTable = (t) => setConfig({ ...config, selectedTables: config.selectedTables.filter(x => x !== t) });
  const reorderTables = (newOrder) => setConfig({ ...config, selectedTables: newOrder });

  // Simple FK warning detection
  const hasFkWarning = config.selectedTables.includes('ORA_ORDERS') &&
    config.selectedTables.includes('ORA_CUSTOMERS') &&
    config.selectedTables.indexOf('ORA_CUSTOMERS') < config.selectedTables.indexOf('ORA_ORDERS');

  const hasFkError = config.selectedTables.includes('ORA_ORDERS') &&
    config.selectedTables.includes('ORA_CUSTOMERS') &&
    config.selectedTables.indexOf('ORA_CUSTOMERS') > config.selectedTables.indexOf('ORA_ORDERS');

  return (
    <div>
      <h3 style={{ fontSize: FONT.size.lg, fontWeight: FONT.weight.medium, marginBottom: SPACING.xxs }}>Select tables & ordering</h3>
      <p style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, marginBottom: SPACING.lg }}>
        Choose source tables and drag to reorder execution sequence.
      </p>
      <div style={{ ...FRSC, gap: SPACING.lg, alignItems: 'flex-start' }}>
        {/* Available tables */}
        <div style={{ flex: 1 }}>
          <p style={{ fontSize: FONT.size.xs, fontWeight: FONT.weight.medium, color: COLORS.text.secondary, marginBottom: '6px' }}>
            {WIZARD.available}
          </p>
          <div style={{ border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.md, padding: '6px' }}>
            <input
              value={search} onChange={e => setSearch(e.target.value)}
              placeholder={WIZARD.search}
              style={{
                width: '100%', padding: '6px 8px', border: `1px solid ${COLORS.border.light}`,
                borderRadius: BORDER_RADIUS.sm, fontSize: FONT.size.sm, marginBottom: '6px', boxSizing: 'border-box',
              }}
            />
            {available.length === 0 && (
              <div style={{ padding: '12px 8px', fontSize: FONT.size.xs, color: COLORS.text.tertiary, textAlign: 'center' }}>
                {search ? 'No tables match your search' : 'All tables have been added'}
              </div>
            )}
            {available.map(t => (
              <div
                key={t}
                onClick={() => addTable(t)}
                style={{
                  ...FRBC, padding: '6px 8px', fontSize: FONT.size.sm, color: COLORS.text.secondary,
                  borderRadius: BORDER_RADIUS.sm, cursor: 'pointer',
                }}
                onMouseEnter={e => e.currentTarget.style.background = COLORS.background.secondary}
                onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
              >
                <span>{t}</span>
                <span style={{ fontSize: '18px', color: COLORS.text.tertiary }}>+</span>
              </div>
            ))}
          </div>
        </div>

        {/* Selected tables — drag to reorder */}
        <div style={{ flex: 1 }}>
          <div style={{ ...FRBC, marginBottom: '6px' }}>
            <p style={{ fontSize: FONT.size.xs, fontWeight: FONT.weight.medium, color: COLORS.text.secondary }}>
              {WIZARD.selected}
            </p>
            <button style={{
              background: 'none', border: 'none', fontSize: FONT.size.xs,
              color: COLORS.brand.primary, cursor: 'pointer',
            }}>
              {WIZARD.smartOrder}
            </button>
          </div>

          <SortableList
            items={config.selectedTables}
            onReorder={reorderTables}
            onRemove={removeTable}
          />

          {/* FK dependency warnings */}
          {hasFkWarning && (
            <div style={{
              marginTop: SPACING.xs, padding: `${SPACING.xs} 10px`,
              background: COLORS.status.successLight, borderRadius: BORDER_RADIUS.md,
              ...FRSC, gap: '6px',
            }}>
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <circle cx="7" cy="7" r="6" stroke="#0F6E56" strokeWidth="1.2" fill="none"/>
                <path d="M4.5 7L6 8.5L9.5 5" stroke="#0F6E56" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span style={{ fontSize: FONT.size.xs, color: COLORS.status.successText }}>
                ORA_ORDERS depends on ORA_CUSTOMERS (FK). Current order is correct.
              </span>
            </div>
          )}
          {hasFkError && (
            <div style={{
              marginTop: SPACING.xs, padding: `${SPACING.xs} 10px`,
              background: COLORS.status.warningLight, borderRadius: BORDER_RADIUS.md,
              ...FRSC, gap: '6px',
            }}>
              <WarningIcon />
              <span style={{ fontSize: FONT.size.xs, color: COLORS.status.warningText }}>
                ORA_ORDERS depends on ORA_CUSTOMERS (FK) — but CUSTOMERS comes after ORDERS. Drag CUSTOMERS above ORDERS.
              </span>
            </div>
          )}

          {config.selectedTables.length > 0 && (
            <p style={{ fontSize: FONT.size.xs, color: COLORS.text.tertiary, marginTop: SPACING.xs }}>
              Drag rows to reorder execution sequence. Tables run top-to-bottom.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

/* ================================================================
   STEP 3: MAPPING PLACEHOLDER
   ================================================================ */
const StepMapping = () => (
  <div style={{ ...FCCC, padding: SPACING.xxxl, color: COLORS.text.secondary }}>
    <p style={{ fontSize: FONT.size.lg, fontWeight: FONT.weight.medium, marginBottom: SPACING.xs }}>Column mapping</p>
    <p style={{ fontSize: FONT.size.md, textAlign: 'center' }}>After creating the pipeline, configure column mappings on the mapping board.</p>
  </div>
);

/* ================================================================
   STEP 4: REVIEW
   ================================================================ */
const StepReview = ({ config, namespaces }) => (
  <div style={{ maxWidth: '480px' }}>
    <h3 style={{ fontSize: FONT.size.lg, fontWeight: FONT.weight.medium, marginBottom: SPACING.lg }}>Review pipeline</h3>
    {[
      ['Name', config.name || '—'],
      ['Description', config.description || '—'],
      ['Namespace', namespaces.find(n => n.id === config.namespaceId)?.name || 'Default'],
      ['Source', MOCK_CONNECTIONS.find(c => c.id === config.source)?.name || '—'],
      ['Target', MOCK_CONNECTIONS.find(c => c.id === config.target)?.name || '—'],
      ['Tables', config.selectedTables.length > 0 ? config.selectedTables.join(' → ') : '—'],
    ].map(([label, value]) => (
      <div key={label} style={{ ...FRSC, gap: SPACING.md, marginBottom: SPACING.sm, fontSize: FONT.size.md }}>
        <span style={{ width: '100px', color: COLORS.text.secondary, flexShrink: 0 }}>{label}</span>
        <span style={{ fontWeight: FONT.weight.medium, wordBreak: 'break-word' }}>{value}</span>
      </div>
    ))}
  </div>
);

/* ================================================================
   MAIN WIZARD
   ================================================================ */
const PipelineWizard = () => {
  const [step, setStep] = useState(0);
  const [namespaces, setNamespaces] = useState([]);
  const [showCreateNs, setShowCreateNs] = useState(false);
  const [config, setConfig] = useState({
    name: '', description: '', namespaceId: 'ns-default', source: '', target: '',
    selectedTables: ['ORA_CUSTOMERS', 'ORA_PRODUCTS', 'ORA_CATEGORIES', 'ORA_ORDERS', 'ORA_ORDER_ITEMS'],
  });
  const navigate = useNavigate();

  useEffect(() => {
    namespaceApi.getAll().then(res => setNamespaces(res.data || []));
  }, []);

  const handleNamespaceCreated = (newNs) => {
    setNamespaces(prev => [...prev, newNs]);
    setConfig(prev => ({ ...prev, namespaceId: newNs.id }));
  };

  const STEPS = [
    <StepBasics config={config} setConfig={setConfig} namespaces={namespaces} onCreateNamespace={() => setShowCreateNs(true)} />,
    <StepConnections config={config} setConfig={setConfig} />,
    <StepTables config={config} setConfig={setConfig} />,
    <StepMapping />,
    <StepReview config={config} namespaces={namespaces} />,
  ];

  return (
    <div>
      <PageHeader title="Create new pipeline" />
      <div style={{
        background: COLORS.background.primary, border: `1px solid ${COLORS.border.light}`,
        borderRadius: BORDER_RADIUS.lg, paddingLeft: SPACING.xl, paddingRight: SPACING.xl, width: '75%',
        height: 'calc(90vh - 40px)', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', overflowY: 'auto',
      }}>
        <div>
          <div style={{ position: 'sticky', top: 0, background: COLORS.background.primary, zIndex: 1, paddingTop: SPACING.xxxl, paddingBottom: SPACING.md }}>
            <StepIndicator steps={WIZARD.steps} currentStep={step} />
          </div>
          <div style={{ minHeight: '300px' }}>{STEPS[step]}</div>
        </div>
        <div style={{ ...FRBC, paddingBottom: SPACING.lg, paddingTop: SPACING.md, borderTop: `1px solid ${COLORS.border.light}`, position: 'sticky', bottom: 0, background: COLORS.background.primary }}>
          <Button variant="secondary" onClick={() => step > 0 ? setStep(step - 1) : navigate('/pipelines')}>
            {WIZARD.back}
          </Button>
          {step < STEPS.length - 1 ? (
            <Button onClick={() => setStep(step + 1)}>Next: {WIZARD.steps[step + 1]}</Button>
          ) : (
            <Button onClick={() => navigate('/pipelines')}>{WIZARD.create}</Button>
          )}
        </div>
      </div>

      {/* Create Namespace Modal */}
      {showCreateNs && (
        <CreateNamespaceModal
          onClose={() => setShowCreateNs(false)}
          onCreated={handleNamespaceCreated}
        />
      )}
    </div>
  );
};

export default PipelineWizard;