import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { COLORS, FONT, SPACING, BORDER_RADIUS } from '../constants/design';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/common';
import { authApi } from '../services/api';

const inputStyle = {
  width: '100%', padding: '10px 12px', border: `1px solid ${COLORS.border.light}`,
  borderRadius: BORDER_RADIUS.md, fontSize: FONT.size.md, boxSizing: 'border-box',
};

const OnboardPage = () => {
  const [mode, setMode] = useState(null); // 'create' | 'request'
  const [orgName, setOrgName] = useState('');
  const [orgSlug, setOrgSlug] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleCreateOrg = async (e) => {
    e.preventDefault();
    if (!orgName.trim()) { setError('Organization name is required'); return; }
    setLoading(true);
    setError(null);
    try {
      await authApi.createOrg({ name: orgName });
      // Re-login to get updated token with orgId
      navigate('/login', { replace: true });
    } catch (err) {
      setError(err.message || 'Failed to create organization');
    } finally {
      setLoading(false);
    }
  };

  const handleRequestAccess = async (e) => {
    e.preventDefault();
    if (!orgSlug.trim()) { setError('Organization slug is required'); return; }
    setLoading(true);
    setError(null);
    try {
      await authApi.requestAccess({ orgSlug });
      setSuccess('Access request sent! An admin will review your request.');
    } catch (err) {
      setError(err.message || 'Failed to send request');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 style={{ fontSize: '20px', fontWeight: 500, margin: '0 0 6px' }}>
        Join an organization
      </h2>
      <p style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, margin: '0 0 24px' }}>
        Hi {user?.fullName || 'there'}! You need to be part of an organization to use Datashifter.
      </p>

      {success ? (
        <div style={{
          background: COLORS.status.successLight, color: COLORS.status.successText,
          padding: '16px', borderRadius: BORDER_RADIUS.md, textAlign: 'center',
          marginBottom: SPACING.md,
        }}>
          <p style={{ fontSize: FONT.size.md, fontWeight: 500, marginBottom: '4px' }}>{success}</p>
          <p style={{ fontSize: FONT.size.xs }}>You'll be notified when approved.</p>
        </div>
      ) : !mode ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: SPACING.sm }}>
          <div
            onClick={() => setMode('create')}
            style={{
              padding: '16px', borderRadius: BORDER_RADIUS.md, cursor: 'pointer',
              border: `1px solid ${COLORS.border.light}`, background: COLORS.background.primary,
              transition: 'all 0.15s',
            }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = COLORS.brand.primary; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = COLORS.border.light; }}
          >
            <p style={{ fontSize: FONT.size.md, fontWeight: 500, margin: '0 0 2px' }}>Create a new organization</p>
            <p style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary, margin: 0 }}>Set up a workspace for your team</p>
          </div>
          <div
            onClick={() => setMode('request')}
            style={{
              padding: '16px', borderRadius: BORDER_RADIUS.md, cursor: 'pointer',
              border: `1px solid ${COLORS.border.light}`, background: COLORS.background.primary,
              transition: 'all 0.15s',
            }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = COLORS.brand.primary; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = COLORS.border.light; }}
          >
            <p style={{ fontSize: FONT.size.md, fontWeight: 500, margin: '0 0 2px' }}>Request access to an existing org</p>
            <p style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary, margin: 0 }}>Ask an admin to add you</p>
          </div>
        </div>
      ) : mode === 'create' ? (
        <form onSubmit={handleCreateOrg}>
          <div style={{ marginBottom: SPACING.md }}>
            <label style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, display: 'block', marginBottom: '4px' }}>Organization name</label>
            <input value={orgName} onChange={e => setOrgName(e.target.value)}
              style={inputStyle} placeholder="e.g., Acme Corp" required autoFocus />
          </div>
          {error && (
            <div style={{ background: COLORS.status.errorLight, color: COLORS.status.errorText, padding: '8px 12px', borderRadius: BORDER_RADIUS.md, fontSize: FONT.size.xs, marginBottom: SPACING.md }}>
              {error}
            </div>
          )}
          <div style={{ display: 'flex', gap: SPACING.xs }}>
            <Button variant="secondary" onClick={() => { setMode(null); setError(null); }}>Back</Button>
            <Button type="submit" style={{ flex: 1, opacity: loading ? 0.6 : 1 }}>
              {loading ? 'Creating...' : 'Create organization'}
            </Button>
          </div>
        </form>
      ) : (
        <form onSubmit={handleRequestAccess}>
          <div style={{ marginBottom: SPACING.md }}>
            <label style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, display: 'block', marginBottom: '4px' }}>Organization slug</label>
            <input value={orgSlug} onChange={e => setOrgSlug(e.target.value)}
              style={inputStyle} placeholder="e.g., acme-corp" required autoFocus />
            <p style={{ fontSize: '11px', color: COLORS.text.tertiary, marginTop: '4px' }}>
              Ask your team admin for the organization slug
            </p>
          </div>
          {error && (
            <div style={{ background: COLORS.status.errorLight, color: COLORS.status.errorText, padding: '8px 12px', borderRadius: BORDER_RADIUS.md, fontSize: FONT.size.xs, marginBottom: SPACING.md }}>
              {error}
            </div>
          )}
          <div style={{ display: 'flex', gap: SPACING.xs }}>
            <Button variant="secondary" onClick={() => { setMode(null); setError(null); }}>Back</Button>
            <Button type="submit" style={{ flex: 1, opacity: loading ? 0.6 : 1 }}>
              {loading ? 'Sending...' : 'Request access'}
            </Button>
          </div>
        </form>
      )}

      <button onClick={logout}
        style={{
          display: 'block', width: '100%', marginTop: '20px', padding: '8px',
          background: 'none', border: 'none', color: COLORS.text.tertiary,
          fontSize: FONT.size.xs, cursor: 'pointer', textAlign: 'center',
        }}>
        Sign out
      </button>
    </div>
  );
};

export default OnboardPage;