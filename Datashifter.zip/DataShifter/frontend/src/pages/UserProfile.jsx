import React, { useState } from 'react';
import { COLORS, FONT, SPACING, BORDER_RADIUS } from '../constants/design';
import { FRSC, FRBC } from '../constants/layouts';
import { PageHeader, Button, Toggle } from '../components/common';

const MOCK_USER = {
  name: 'Dharmaraj R',
  email: 'dharr@paypal.com',
  role: 'Admin',
  org: 'PayPal.',
  timezone: 'Asia/Kolkata',
  joinedAt: '2025-12-27T15:30:00Z',
};

const Field = ({ label, value, editable, onChange }) => (
  <div style={{ marginBottom: SPACING.md }}>
    <label style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, display: 'block', marginBottom: SPACING.xxs }}>{label}</label>
    {editable ? (
      <input
        value={value} onChange={e => onChange(e.target.value)}
        style={{
          width: '100%', padding: `${SPACING.xs} 10px`, border: `1px solid ${COLORS.border.light}`,
          borderRadius: BORDER_RADIUS.md, fontSize: FONT.size.md, boxSizing: 'border-box',
        }}
      />
    ) : (
      <p style={{ fontSize: FONT.size.md, fontWeight: FONT.weight.medium, color: COLORS.text.primary }}>{value}</p>
    )}
  </div>
);

const SettingRow = ({ label, description, children }) => (
  <div style={{
    ...FRBC, padding: `${SPACING.sm} ${SPACING.md}`,
    background: COLORS.background.secondary, borderRadius: BORDER_RADIUS.md,
    marginBottom: SPACING.xs,
  }}>
    <div>
      <p style={{ fontSize: FONT.size.md, fontWeight: FONT.weight.medium }}>{label}</p>
      <p style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary, marginTop: '2px' }}>{description}</p>
    </div>
    {children}
  </div>
);

const UserProfile = () => {
  const [user, setUser] = useState(MOCK_USER);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(false);

  const update = (key, val) => setUser(prev => ({ ...prev, [key]: val }));

  return (
    <div>
      <PageHeader title="Profile" subtitle="Manage your account and preferences" />

      <div style={{ maxWidth: '580px' }}>
        {/* Avatar + name header */}
        <div style={{
          ...FRSC, gap: SPACING.md, marginBottom: SPACING.xl,
          padding: SPACING.lg, background: COLORS.background.primary,
          border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.lg,
        }}>
          <div style={{
            width: 56, height: 56, borderRadius: '50%', background: COLORS.brand.primary,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: FONT.size.xl, fontWeight: FONT.weight.medium, color: '#fff', flexShrink: 0,
          }}>
            {user.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()}
          </div>
          <div>
            <p style={{ fontSize: FONT.size.xl, fontWeight: FONT.weight.medium }}>{user.name}</p>
            <p style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, marginTop: '2px' }}>{user.role} at {user.org}</p>
          </div>
        </div>

        {/* Account info */}
        <div style={{
          padding: SPACING.lg, background: COLORS.background.primary,
          border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.lg,
          marginBottom: SPACING.lg,
        }}>
          <p style={{ fontSize: FONT.size.base, fontWeight: FONT.weight.medium, marginBottom: SPACING.md }}>Account information</p>
          <Field label="Full name" value={user.name} editable onChange={v => update('name', v)} />
          <Field label="Email" value={user.email} editable onChange={v => update('email', v)} />
          <Field label="Role" value={user.role} />
          <Field label="Organization" value={user.org} />
          <Field label="Timezone" value={user.timezone} editable onChange={v => update('timezone', v)} />
          <Field label="Member since" value={new Date(user.joinedAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })} />
          <div style={{ ...FRSC, gap: SPACING.xs, marginTop: SPACING.sm }}>
            <Button>Save changes</Button>
          </div>
        </div>

        {/* Preferences */}
        <div style={{
          padding: SPACING.lg, background: COLORS.background.primary,
          border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.lg,
          marginBottom: SPACING.lg,
        }}>
          <p style={{ fontSize: FONT.size.base, fontWeight: FONT.weight.medium, marginBottom: SPACING.md }}>Preferences</p>
          <SettingRow label="Email notifications" description="Receive alerts when pipelines complete, fail, or need attention">
            <Toggle checked={emailNotifications} onChange={setEmailNotifications} />
          </SettingRow>
          <SettingRow label="Dark mode" description="Switch to dark theme (coming soon)">
            <Toggle checked={darkMode} onChange={setDarkMode} />
          </SettingRow>
        </div>

        {/* Security */}
        <div style={{
          padding: SPACING.lg, background: COLORS.background.primary,
          border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.lg,
        }}>
          <p style={{ fontSize: FONT.size.base, fontWeight: FONT.weight.medium, marginBottom: SPACING.md }}>Security</p>
          <div style={{ ...FRBC, marginBottom: SPACING.sm }}>
            <div>
              <p style={{ fontSize: FONT.size.md }}>Password</p>
              <p style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary, marginTop: '2px' }}>Last changed 30 days ago</p>
            </div>
            <Button variant="secondary" size="sm">Change password</Button>
          </div>
          <div style={{ ...FRBC }}>
            <div>
              <p style={{ fontSize: FONT.size.md }}>Active sessions</p>
              <p style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary, marginTop: '2px' }}>1 active session on this device</p>
            </div>
            <Button variant="secondary" size="sm">Manage sessions</Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;