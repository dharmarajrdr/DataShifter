import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { COLORS, FONT, SPACING, BORDER_RADIUS } from '../constants/design';
import { FRSC, FRBC, FRWSC, FCSS } from '../constants/layouts';
import { ERRORS } from '../constants/literals';
import { PageHeader, MetricCard, Button, Chip, StatusBadge } from '../components/common';
import { errorApi } from '../services/api';

const ERROR_TYPE_COLORS = {
  TYPE_CAST_FAILED: 'error',
  NULL_CONSTRAINT: 'warning',
  PK_DUPLICATE: 'purple',
  WRITE_TIMEOUT: 'default',
};

const ErrorEntry = ({ error }) => {
  const colorScheme = ERROR_TYPE_COLORS[error.type] || 'default';
  return (
    <div style={{ padding: `${SPACING.sm} ${SPACING.md}`, borderBottom: `1px solid ${COLORS.border.light}` }}>
      <div style={{ ...FRBC, marginBottom: '6px' }}>
        <div style={{ ...FRSC, gap: SPACING.xs }}>
          <Chip label={error.type} colorScheme={colorScheme} />
          <span style={{ fontSize: FONT.size.sm, fontWeight: FONT.weight.medium }}>
            {error.sourceTable} → {error.targetTable}
          </span>
        </div>
        <span style={{ fontSize: FONT.size.xs, color: COLORS.text.tertiary }}>
          Chunk #{error.chunk} · Row #{error.row}
        </span>
      </div>
      <p style={{
        fontSize: FONT.size.sm, color: COLORS.text.secondary, fontFamily: 'monospace',
        marginBottom: SPACING.xs,
      }}>{error.message}</p>
      <div style={{
        background: COLORS.background.secondary, borderRadius: BORDER_RADIUS.md,
        padding: `${SPACING.xs} 10px`,
      }}>
        <p style={{ fontSize: '10px', fontWeight: FONT.weight.medium, color: COLORS.text.secondary, marginBottom: SPACING.xxs }}>
          {ERRORS.sourceRowData}
        </p>
        <p style={{ fontSize: FONT.size.xs, fontFamily: 'monospace', wordBreak: 'break-all' }}>
          {error.sourceData}
        </p>
      </div>
    </div>
  );
};

const ErrorLogViewer = () => {
  const [data, setData] = useState(null);
  const [search, setSearch] = useState('');
  const [filterTable, setFilterTable] = useState('all');
  const { pipelineId } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    errorApi.getByPipelineId(pipelineId).then(res => setData(res.data));
  }, [pipelineId]);

  if (!data) return null;

  const filteredErrors = data.errors.filter(e => {
    const matchesSearch = search === '' || e.message.toLowerCase().includes(search.toLowerCase()) || String(e.row).includes(search);
    const matchesTable = filterTable === 'all' || e.sourceTable === filterTable;
    return matchesSearch && matchesTable;
  });

  const uniqueTables = [...new Set(data.errors.map(e => e.sourceTable))];

  return (
    <div>
      <PageHeader
        breadcrumbs={[
          { label: data.pipelineName, onClick: () => navigate(`/pipelines/${pipelineId}/monitor`) },
          { label: ERRORS.title },
        ]}
        actions={<Button variant="secondary">{ERRORS.exportCsv}</Button>}
      />

      {/* Summary metrics */}
      <div style={{ ...FRSC, gap: SPACING.sm, marginBottom: SPACING.lg }}>
        <MetricCard label={ERRORS.totalErrors} value={data.summary.total} color={COLORS.status.errorDark} />
        <MetricCard label={ERRORS.skipped} value={data.summary.skipped} color={COLORS.status.warningDark} />
        <MetricCard label={ERRORS.pipelineStopped} value={data.summary.stopped} color={COLORS.status.errorDark} />
        <MetricCard label={ERRORS.errorRate} value={data.summary.errorRate} />
      </div>

      {/* Error type chips */}
      <div style={{ marginBottom: SPACING.md }}>
        <p style={{ fontSize: FONT.size.xs, fontWeight: FONT.weight.medium, color: COLORS.text.secondary, marginBottom: SPACING.xs }}>
          {ERRORS.errorsByType}
        </p>
        <div style={{ ...FRWSC, gap: '6px' }}>
          {data.errorTypes.map(et => (
            <Chip
              key={et.type}
              label={`${et.type} (${et.count})`}
              colorScheme={ERROR_TYPE_COLORS[et.type] || 'default'}
              onClick={() => {}}
            />
          ))}
        </div>
      </div>

      {/* Filters */}
      <div style={{ ...FRSC, gap: SPACING.xs, marginBottom: SPACING.sm }}>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder={ERRORS.searchPlaceholder}
          style={{
            flex: 1, padding: '7px 10px', border: `1px solid ${COLORS.border.light}`,
            borderRadius: BORDER_RADIUS.md, fontSize: FONT.size.sm,
          }}
        />
        <select
          value={filterTable}
          onChange={e => setFilterTable(e.target.value)}
          style={{
            padding: '7px 10px', border: `1px solid ${COLORS.border.light}`,
            borderRadius: BORDER_RADIUS.md, fontSize: FONT.size.sm, background: COLORS.background.primary,
          }}
        >
          <option value="all">All tables</option>
          {uniqueTables.map(t => <option key={t} value={t}>{t}</option>)}
        </select>
      </div>

      {/* Error list */}
      <div style={{
        border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.md,
        overflow: 'hidden', background: COLORS.background.primary,
      }}>
        {filteredErrors.length === 0 ? (
          <div style={{ padding: SPACING.xl, textAlign: 'center', color: COLORS.text.secondary, fontSize: FONT.size.md }}>
            No errors match your filters.
          </div>
        ) : (
          filteredErrors.map(error => <ErrorEntry key={error.id} error={error} />)
        )}
      </div>

      {/* Pagination */}
      <div style={{ ...FRBC, marginTop: SPACING.sm }}>
        <span style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary }}>
          Showing 1-{filteredErrors.length} of {data.summary.total} errors
        </span>
        <div style={{ ...FRSC, gap: SPACING.xxs }}>
          {['Prev', '1', '2', '3', 'Next'].map((label, i) => (
            <Button key={label} variant={label === '1' ? 'primary' : 'secondary'} size="sm">{label}</Button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ErrorLogViewer;
