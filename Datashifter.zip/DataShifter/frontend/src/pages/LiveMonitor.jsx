import React, { useState, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { COLORS, FONT, SPACING, BORDER_RADIUS } from '../constants/design';
import { FRSC, FRBC, FRWSC } from '../constants/layouts';
import { MONITOR } from '../constants/literals';
import { PageHeader, MetricCard, StatusBadge, ProgressBar, Button, Chip } from '../components/common';
import { monitorApi, pipelineApi } from '../services/api';
import { usePolling } from '../hooks/usePolling';

/* ================================================================
   POLLING INTERVAL OPTIONS
   ================================================================ */
const INTERVAL_OPTIONS = [
  { label: 'Off', value: 0 },
  { label: '3s', value: 3000 },
  { label: '5s', value: 5000 },
  { label: '10s', value: 10000 },
  { label: '30s', value: 30000 },
];

const TERMINAL_STATES = ['COMPLETED', 'ERRORED', 'PAUSED', 'DRAFT'];

/* ================================================================
   LAST UPDATED DISPLAY
   ================================================================ */
const formatLastUpdated = (date) => {
  if (!date) return '';
  const now = new Date();
  const diff = Math.floor((now - date) / 1000);
  if (diff < 5) return 'just now';
  if (diff < 60) return `${diff}s ago`;
  return date.toLocaleTimeString();
};

/* ================================================================
   MAIN COMPONENT
   ================================================================ */
const LiveMonitor = () => {
  const { pipelineId } = useParams();
  const navigate = useNavigate();
  const [actionLoading, setActionLoading] = useState(null);

  // Auto-polling — stops when pipeline is not RUNNING
  const stopWhen = useCallback((data) => {
    return data ? TERMINAL_STATES.includes(data.status) : false;
  }, []);

  const {
    data, loading, lastUpdated, refreshCount, interval, setInterval, refresh, isPolling,
  } = usePolling(
    () => monitorApi.getByPipelineId(pipelineId),
    { defaultInterval: 5000, stopWhen, deps: [pipelineId] }
  );

  /* --- Pipeline actions --- */
  const handleAction = async (action) => {
    setActionLoading(action);
    try {
      await pipelineApi.performAction(pipelineId, action);
      refresh(); // reload status immediately after action
    } catch (e) {
      console.error(`Failed to ${action} pipeline:`, e);
    } finally {
      setActionLoading(null);
    }
  };

  if (loading && !data) {
    return (
      <div style={{ padding: '60px', textAlign: 'center', color: COLORS.text.secondary }}>
        Loading pipeline monitor...
      </div>
    );
  }

  if (!data) return null;

  const tableChipColor = (status) => {
    if (status === 'COMPLETED') return 'purple';
    if (status === 'RUNNING') return 'teal';
    return 'default';
  };

  const inflightCols = data.inflightRecords && data.inflightRecords.length > 0
    ? Object.keys(data.inflightRecords[0]) : [];

  const isRunning = data.status === 'RUNNING';
  const isPaused = data.status === 'PAUSED';

  return (
    <div>
      <PageHeader
        breadcrumbs={[
          { label: data.pipelineName || 'Pipeline', onClick: () => navigate('/pipelines') },
          { label: MONITOR.title },
        ]}
        actions={<>
          <StatusBadge status={data.status} />
          {isRunning && (
            <Button variant="warning" size="md"
              onClick={() => handleAction('PAUSE')}
              style={actionLoading === 'PAUSE' ? { opacity: 0.6 } : {}}>
              {actionLoading === 'PAUSE' ? 'Pausing...' : MONITOR.pause}
            </Button>
          )}
          {isPaused && (
            <Button variant="primary" size="md"
              onClick={() => handleAction('RESUME')}>
              {actionLoading === 'RESUME' ? 'Resuming...' : MONITOR.resume}
            </Button>
          )}
          {(isRunning || isPaused) && (
            <Button variant="danger" size="md"
              onClick={() => handleAction('STOP')}
              style={actionLoading === 'STOP' ? { opacity: 0.6 } : {}}>
              {actionLoading === 'STOP' ? 'Stopping...' : MONITOR.stop}
            </Button>
          )}
        </>}
      />

      {/* Polling controls */}
      <div style={{
        ...FRBC, marginBottom: SPACING.md,
        padding: `${SPACING.xs} ${SPACING.md}`,
        background: COLORS.background.secondary, borderRadius: BORDER_RADIUS.md,
      }}>
        <div style={{ ...FRSC, gap: SPACING.sm }}>
          <span style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary }}>Auto-refresh:</span>
          {INTERVAL_OPTIONS.map(opt => (
            <span
              key={opt.value}
              onClick={() => setInterval(opt.value)}
              style={{
                fontSize: FONT.size.xs, padding: '2px 8px', borderRadius: BORDER_RADIUS.sm,
                cursor: 'pointer', fontWeight: FONT.weight.medium,
                background: interval === opt.value ? COLORS.brand.primary : 'transparent',
                color: interval === opt.value ? '#fff' : COLORS.text.secondary,
                transition: 'all 0.15s',
              }}
            >{opt.label}</span>
          ))}
          {isPolling && (
            <span style={{
              width: 6, height: 6, borderRadius: '50%', background: COLORS.status.success,
              animation: 'pulse 2s infinite',
            }} />
          )}
        </div>
        <div style={{ ...FRSC, gap: SPACING.xs }}>
          {lastUpdated && (
            <span style={{ fontSize: FONT.size.xs, color: COLORS.text.tertiary }}>
              Updated {formatLastUpdated(lastUpdated)}
            </span>
          )}
          <Button variant="secondary" size="sm" onClick={refresh}>
            {MONITOR.refresh}
          </Button>
        </div>
      </div>

      {/* Metric cards */}
      <div
        key={refreshCount}
        style={{
          ...FRSC, gap: SPACING.sm, marginBottom: SPACING.lg,
          animation: refreshCount > 1 ? 'fadeIn 0.3s ease' : 'none',
        }}
      >
        <MetricCard label={MONITOR.rowsProcessed} value={data.rowsProcessed ? data.rowsProcessed.toLocaleString() : '0'} />
        <MetricCard label={MONITOR.rowsPerSec} value={data.rowsPerSec ? data.rowsPerSec.toLocaleString() : '0'} />
        <MetricCard label={MONITOR.errorsSkipped} value={data.errorsSkipped || 0} color={COLORS.status.errorDark} />
        <MetricCard label={MONITOR.eta} value={data.eta || '—'} />
      </div>

      {/* Overall progress */}
      <div style={{ marginBottom: SPACING.lg }}>
        <div style={{ ...FRBC, marginBottom: '6px' }}>
          <span style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary }}>{MONITOR.overallProgress}</span>
          <span style={{ fontSize: FONT.size.sm, fontWeight: FONT.weight.medium }}>
            {data.overallProgress ? data.overallProgress.toFixed(1) : 0}%
          </span>
        </div>
        <ProgressBar progress={data.overallProgress || 0} height="8px" showLabel={false} />
      </div>

      {/* Table progress chips */}
      {data.tables && data.tables.length > 0 && (
        <div style={{ marginBottom: SPACING.lg }}>
          <p style={{ fontSize: FONT.size.sm, fontWeight: FONT.weight.medium, color: COLORS.text.secondary, marginBottom: SPACING.xs }}>
            {MONITOR.tableProgress}
          </p>
          <div style={{ ...FRWSC, gap: '6px' }}>
            {data.tables.map(t => (
              <Chip
                key={t.name}
                label={`${t.name} ${t.progress > 0 ? t.progress + '%' : ''}`}
                colorScheme={tableChipColor(t.status)}
              />
            ))}
          </div>
        </div>
      )}

      {/* In-flight records */}
      <div>
        <div style={{ ...FRBC, marginBottom: SPACING.xs }}>
          <p style={{ fontSize: FONT.size.sm, fontWeight: FONT.weight.medium, color: COLORS.text.secondary }}>
            {MONITOR.inflightRecords}
          </p>
          {inflightCols.length > 0 && (
            <span style={{ fontSize: FONT.size.xs, color: COLORS.text.tertiary }}>
              {data.inflightRecords.length} records
            </span>
          )}
        </div>
        <div style={{
          border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.md,
          overflow: 'auto', background: COLORS.background.primary,
        }}>
          {inflightCols.length === 0 ? (
            <div style={{ padding: '24px', textAlign: 'center', color: COLORS.text.tertiary, fontSize: FONT.size.sm }}>
              {isRunning ? 'Waiting for records...' : 'No in-flight records'}
            </div>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: FONT.size.xs }}>
              <thead>
                <tr style={{ background: COLORS.background.secondary }}>
                  {inflightCols.map(col => (
                    <th key={col} style={{
                      textAlign: 'left', padding: `${SPACING.xs} 10px`,
                      fontWeight: FONT.weight.medium, color: COLORS.text.secondary, whiteSpace: 'nowrap',
                    }}>{col}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.inflightRecords.map((row, i) => (
                  <tr key={`${refreshCount}-${i}`} style={{
                    borderTop: `1px solid ${COLORS.border.light}`,
                    background: i % 2 === 1 ? COLORS.background.secondary : 'transparent',
                    animation: refreshCount > 1 ? `fadeIn 0.2s ease ${i * 0.02}s both` : 'none',
                  }}>
                    {inflightCols.map(col => (
                      <td key={col} style={{
                        padding: '7px 10px', fontFamily: 'monospace', color: COLORS.text.primary,
                        whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '160px',
                      }}>{String(row[col])}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        <p style={{ fontSize: FONT.size.xs, color: COLORS.text.tertiary, marginTop: '6px', textAlign: 'right' }}>
          Showing transformed records as they will be written to target
        </p>
      </div>

      {/* Quick links */}
      <div style={{ ...FRSC, gap: SPACING.sm, marginTop: SPACING.lg }}>
        <Button variant="secondary" size="sm" onClick={() => navigate(`/pipelines/${pipelineId}/errors`)}>
          View error logs
        </Button>
        <Button variant="secondary" size="sm" onClick={() => navigate(`/pipelines/${pipelineId}/mapping`)}>
          View column mapping
        </Button>
        <Button variant="secondary" size="sm" onClick={() => navigate(`/pipelines/${pipelineId}/settings`)}>
          Pipeline settings
        </Button>
      </div>

      {/* CSS animations */}
      <style>{`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(2px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
      `}</style>
    </div>
  );
};

export default LiveMonitor;