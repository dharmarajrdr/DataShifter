import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { COLORS, FONT, SPACING, BORDER_RADIUS } from '../constants/design';
import { FRSC, FRBC, FRWSC } from '../constants/layouts';
import { MAPPING as LIT } from '../constants/literals';
import { PageHeader, Button, Chip } from '../components/common';
import DragMappingBoard from '../components/pipeline/DragMappingBoard';
import { mappingApi } from '../services/api';

const COL_COLORS = {
  purple: { bg: '#EEEDFE', text: '#3C3489', border: '#AFA9EC' },
  teal: { bg: '#E1F5EE', text: '#085041', border: '#5DCAA5' },
  coral: { bg: '#FAECE7', text: '#712B13', border: '#F0997B' },
  pink: { bg: '#FBEAF0', text: '#72243E', border: '#ED93B1' },
  blue: { bg: '#E6F1FB', text: '#0C447C', border: '#85B7EB' },
};

const ColumnMappingBoard = () => {
  const [mapping, setMapping] = useState(null);
  const [mappings, setMappings] = useState([]);
  const [hasChanges, setHasChanges] = useState(false);
  const { pipelineId } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    mappingApi.getByPipelineId(pipelineId).then(res => {
      setMapping(res.data);
      setMappings(res.data.mappings || []);
    });
  }, [pipelineId]);

  if (!mapping) return null;

  const handleMappingsChange = (newMappings) => {
    setMappings(newMappings);
    setHasChanges(true);
  };

  const handleMappingClick = (m) => {
    // Navigate to transformation builder for this mapping
    navigate(`/pipelines/${pipelineId}/transform`);
  };

  const handleSave = () => {
    // Save updated mappings to backend
    mappingApi.save(pipelineId, { ...mapping, mappings }).then(() => {
      setHasChanges(false);
    });
  };

  const handleAutoMap = () => {
    // Auto-map by matching column names (case-insensitive)
    const colorKeys = ['purple', 'teal', 'coral', 'pink', 'blue'];
    const autoMapped = [];
    mapping.sourceColumns.forEach((src) => {
      const match = mapping.targetColumns.find(tgt =>
        tgt.name.replace(/_/g, '').toLowerCase() === src.name.replace(/_/g, '').toLowerCase()
      );
      if (match && !autoMapped.some(m => m.target === match.name)) {
        autoMapped.push({
          source: src.name,
          target: match.name,
          color: colorKeys[autoMapped.length % colorKeys.length],
          transforms: [],
        });
      }
    });
    handleMappingsChange(autoMapped);
  };

  const transformedMappings = mappings.filter(m => m.transforms && m.transforms.length > 0);

  return (
    <div>
      <PageHeader
        breadcrumbs={[
          { label: mapping.pipelineName, onClick: () => navigate('/pipelines') },
          { label: LIT.title },
        ]}
        actions={<>
          <Button variant="secondary" size="md" onClick={handleAutoMap}>{LIT.autoMap}</Button>
          <Button size="md" onClick={handleSave} style={hasChanges ? {} : { opacity: 0.5 }}>
            {hasChanges ? 'Save mapping *' : LIT.saveMapping}
          </Button>
        </>}
      />

      {/* Interactive Mapping Board */}
      <DragMappingBoard
        sourceColumns={mapping.sourceColumns}
        targetColumns={mapping.targetColumns}
        mappings={mappings}
        onMappingsChange={handleMappingsChange}
        onMappingClick={handleMappingClick}
        sourceTable={mapping.sourceTable}
        targetTable={mapping.targetTable}
      />

      {/* Mapping count + instructions */}
      <div style={{
        ...FRBC, marginTop: SPACING.sm,
        padding: `${SPACING.xs} ${SPACING.md}`,
        fontSize: FONT.size.xs, color: COLORS.text.secondary,
      }}>
        <span>{mappings.length} column{mappings.length !== 1 ? 's' : ''} mapped</span>
        <span>Drag from a source dot to a target dot to create a mapping. Click a line to edit or delete.</span>
      </div>

      {/* Write Mode */}
      <div style={{
        ...FRSC, gap: SPACING.sm, marginTop: SPACING.sm,
        padding: `${SPACING.sm} ${SPACING.md}`, background: COLORS.background.secondary,
        borderRadius: BORDER_RADIUS.md,
      }}>
        <span style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary }}>{LIT.writeMode}:</span>
        <Chip label={mapping.writeMode} colorScheme="teal" />
      </div>

      {/* Active Transformations */}
      {transformedMappings.length > 0 && (
        <div style={{ marginTop: SPACING.lg }}>
          <p style={{ fontSize: FONT.size.sm, fontWeight: FONT.weight.medium, color: COLORS.text.secondary, marginBottom: SPACING.xs }}>
            {LIT.activeTransformations}
          </p>
          <div style={{ ...FRWSC, gap: SPACING.xs }}>
            {transformedMappings.map((m, i) => {
              const scheme = COL_COLORS[m.color] || COL_COLORS.purple;
              return (
                <div
                  key={i}
                  onClick={() => handleMappingClick(m)}
                  style={{
                    background: scheme.bg, border: `1px solid ${scheme.border}`,
                    borderRadius: BORDER_RADIUS.md, padding: `6px ${SPACING.sm}`,
                    fontSize: FONT.size.xs, color: scheme.text, cursor: 'pointer',
                  }}
                >
                  {m.source} → <span style={{ fontFamily: 'monospace', fontWeight: FONT.weight.medium }}>
                    {m.transforms.map(t => `${t.fn}(${t.args || ''})`).join(' → ')}
                  </span> → {m.target}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Source filter placeholder */}
      <div style={{
        marginTop: SPACING.sm, padding: `${SPACING.sm} ${SPACING.md}`,
        background: COLORS.background.secondary, borderRadius: BORDER_RADIUS.md,
        ...FRSC, gap: SPACING.xs, cursor: 'pointer', color: COLORS.text.secondary, fontSize: FONT.size.sm,
      }}>
        <span style={{ fontSize: '16px' }}>+</span> {LIT.addFilter}
      </div>
    </div>
  );
};

export default ColumnMappingBoard;