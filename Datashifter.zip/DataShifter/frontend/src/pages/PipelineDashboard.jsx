import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { COLORS, FONT, SPACING, BORDER_RADIUS } from '../constants/design';
import { FRSC, FRBC, FRWSC } from '../constants/layouts';
import { PIPELINE } from '../constants/literals';
import { PageHeader, MetricCard, StatusBadge, ProgressBar, Button } from '../components/common';
import CreateNamespaceModal from '../components/pipeline/CreateNamespaceModal';
import { pipelineApi, namespaceApi } from '../services/api';

/* ================================================================
   OWNER AVATAR — small circle with initials
   ================================================================ */
const OwnerAvatar = ({ name, initials, color, size = 24 }) => (
  <div
    title={name || 'Unknown'}
    style={{
      width: size, height: size, borderRadius: '50%', flexShrink: 0,
      background: color || COLORS.brand.primary,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: Math.round(size * 0.42), fontWeight: 500, color: '#fff',
      cursor: 'default',
    }}
  >
    {initials || '?'}
  </div>
);

/* ================================================================
   PIPELINE ROW — draggable
   ================================================================ */
const PipelineRow = ({ pipeline, navigate, onDragStart }) => (
  <div
    draggable
    onDragStart={(e) => {
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', pipeline.id);
      onDragStart(pipeline.id);
      setTimeout(() => { e.target.style.opacity = '0.4'; }, 0);
    }}
    onDragEnd={(e) => { e.target.style.opacity = '1'; }}
    style={{
      background: COLORS.background.primary, border: `1px solid ${COLORS.border.light}`,
      borderRadius: BORDER_RADIUS.md, padding: `${SPACING.sm} ${SPACING.md}`, marginBottom: SPACING.xs,
      cursor: 'grab', userSelect: 'none',
    }}
  >
    <div style={{ ...FRBC }}>
      <div style={{ ...FRSC, gap: SPACING.sm, flex: 1, minWidth: 0 }}>
        {/* Owner avatar */}
        <OwnerAvatar
          name={pipeline.ownerName}
          initials={pipeline.ownerInitials}
          color={pipeline.ownerColor}
        />
        
        <div style={{ minWidth: 0, flex: 1 }}>
          <p
            onClick={() => navigate(`/pipelines/${pipeline.id}/monitor`)}
            style={{
              fontSize: FONT.size.md, fontWeight: FONT.weight.medium,
              cursor: 'pointer', color: COLORS.text.primary,
              whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
              margin: 0,
            }}
            onMouseEnter={e => e.target.style.color = COLORS.brand.primary}
            onMouseLeave={e => e.target.style.color = COLORS.text.primary}
          >
            {pipeline.name}
          </p>
          <p style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary, marginTop: '2px', margin: 0 }}>
            {pipeline.source} → {pipeline.target} · {pipeline.tableCount} tables
            <span style={{ color: COLORS.text.tertiary }}> · {pipeline.ownerName}</span>
          </p>
        </div>
      </div>
      <StatusBadge status={pipeline.status} />
      <div style={{ ...FRSC, gap: SPACING.sm, flexShrink: 0, marginLeft: SPACING.md }}>
        {pipeline.progress >= 0 && pipeline.progress <= 100 && (
          <div style={{ width: 200 }}>
            <ProgressBar progress={pipeline.progress} height="4px" showLabel={true} />
          </div>
        )}
        <div style={{ ...FRSC, gap: '4px' }}>
          <Button variant="secondary" size="sm" onClick={() => navigate(`/pipelines/${pipeline.id}/mapping`)}>Map</Button>
          <Button variant="secondary" size="sm" onClick={() => navigate(`/pipelines/${pipeline.id}/monitor`)}>Monitor</Button>
          <Button variant="secondary" size="sm" onClick={() => navigate(`/pipelines/${pipeline.id}/settings`)}>Settings</Button>
        </div>
      </div>
    </div>
  </div>
);

/* ================================================================
   NAMESPACE GROUP — drop target for pipeline drag
   ================================================================ */
const NamespaceGroup = ({ namespace, pipelines, navigate, onDragStart, onDropPipeline, dragOverNs, setDragOverNs }) => {
  const [collapsed, setCollapsed] = useState(false);
  const isDropTarget = dragOverNs === namespace.id;

  return (
    <div
      style={{ marginBottom: SPACING.md }}
      onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; setDragOverNs(namespace.id); }}
      onDragLeave={(e) => {
        // Only clear if leaving the group entirely, not entering a child
        if (!e.currentTarget.contains(e.relatedTarget)) setDragOverNs(null);
      }}
      onDrop={(e) => {
        e.preventDefault();
        const pipelineId = e.dataTransfer.getData('text/plain');
        if (pipelineId) onDropPipeline(pipelineId, namespace.id, namespace.name);
        setDragOverNs(null);
      }}
    >
      {/* Group header */}
      <div
        style={{
          ...FRBC, padding: `${SPACING.xs} ${SPACING.sm}`, cursor: 'pointer',
          marginBottom: collapsed ? 0 : SPACING.xs,
          borderRadius: BORDER_RADIUS.md,
          border: isDropTarget ? `2px dashed ${namespace.color || COLORS.brand.primary}` : '2px solid transparent',
          background: isDropTarget ? (namespace.color || COLORS.brand.primary) + '10' : 'transparent',
          transition: 'all 0.15s',
        }}
      >
        <div style={{ ...FRSC, gap: SPACING.xs }} onClick={() => setCollapsed(!collapsed)}>
          <span style={{ fontSize: '11px', color: COLORS.text.tertiary, width: '14px' }}>
            {collapsed ? '▶' : '▼'}
          </span>
          <div style={{
            width: 10, height: 10, borderRadius: '2px',
            background: namespace.color || COLORS.brand.primary, flexShrink: 0,
          }} />
          <span style={{ fontSize: FONT.size.md, fontWeight: FONT.weight.medium, color: COLORS.text.primary }}>
            {namespace.name}
          </span>
          <span style={{
            fontSize: FONT.size.xs, color: COLORS.text.tertiary,
            background: COLORS.background.secondary, padding: '1px 8px',
            borderRadius: BORDER_RADIUS.pill,
          }}>
            {pipelines.length}
          </span>
        </div>
        {isDropTarget && (
          <span style={{ fontSize: FONT.size.xs, color: namespace.color || COLORS.brand.primary, fontWeight: FONT.weight.medium }}>
            Drop here
          </span>
        )}
        {!isDropTarget && namespace.description && !collapsed && (
          <span style={{ fontSize: FONT.size.xs, color: COLORS.text.tertiary }}>{namespace.description}</span>
        )}
      </div>

      {/* Pipeline cards */}
      {!collapsed && (
        <div style={{ paddingLeft: '24px', minHeight: isDropTarget ? '40px' : 'auto' }}>
          {pipelines.length === 0 && isDropTarget && (
            <div style={{
              padding: SPACING.sm, textAlign: 'center', color: COLORS.text.tertiary,
              fontSize: FONT.size.xs, border: `1px dashed ${COLORS.border.medium}`,
              borderRadius: BORDER_RADIUS.md,
            }}>
              Drop pipeline here to move it to {namespace.name}
            </div>
          )}
          {pipelines.map(p => (
            <PipelineRow key={p.id} pipeline={p} navigate={navigate} onDragStart={onDragStart} />
          ))}
        </div>
      )}
    </div>
  );
};

/* ================================================================
   MAIN PAGE
   ================================================================ */
const PipelineDashboard = () => {
  const [pipelines, setPipelines] = useState([]);
  const [namespaces, setNamespaces] = useState([]);
  const [search, setSearch] = useState('');
  const [selectedNamespaces, setSelectedNamespaces] = useState([]);
  const [dragOverNs, setDragOverNs] = useState(null);
  const [draggingPipelineId, setDraggingPipelineId] = useState(null);
  const [showCreateNs, setShowCreateNs] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    pipelineApi.getAll().then(res => setPipelines(res.data || []));
    namespaceApi.getAll().then(res => setNamespaces(res.data || []));
  }, []);

  /* --- Search + namespace filter --- */
  const filteredPipelines = useMemo(() => {
    let result = pipelines;
    if (selectedNamespaces.length > 0) {
      result = result.filter(p => selectedNamespaces.includes(p.namespaceId));
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(q) ||
        (p.source || '').toLowerCase().includes(q) ||
        (p.target || '').toLowerCase().includes(q) ||
        (p.status || '').toLowerCase().includes(q) ||
        (p.namespaceName || '').toLowerCase().includes(q) ||
        (p.ownerName || '').toLowerCase().includes(q)
      );
    }
    return result;
  }, [pipelines, search, selectedNamespaces]);

  /* --- Group by namespace --- */
  const groupedPipelines = useMemo(() => {
    const groups = {};

    // Ensure all namespaces appear even if empty (for drop targets)
    for (const ns of namespaces) {
      groups[ns.id] = [];
    }

    for (const p of filteredPipelines) {
      const nsId = p.namespaceId || 'ns-default';
      if (!groups[nsId]) groups[nsId] = [];
      groups[nsId].push(p);
    }

    const sortedNsIds = Object.keys(groups).sort((a, b) => {
      if (a === 'ns-default') return 1;
      if (b === 'ns-default') return -1;
      const nameA = namespaces.find(n => n.id === a)?.name || '';
      const nameB = namespaces.find(n => n.id === b)?.name || '';
      return nameA.localeCompare(nameB);
    });

    return sortedNsIds.map(nsId => ({
      namespace: namespaces.find(n => n.id === nsId) || { id: nsId, name: 'Default', color: '#888780' },
      pipelines: groups[nsId],
    }));
  }, [filteredPipelines, namespaces]);

  /* --- Drag & drop pipeline between namespaces --- */
  const handleDropPipeline = useCallback(async (pipelineId, namespaceId, namespaceName) => {
    const pipeline = pipelines.find(p => p.id === pipelineId);
    if (!pipeline || pipeline.namespaceId === namespaceId) return;

    // Optimistic update
    setPipelines(prev => prev.map(p =>
      p.id === pipelineId ? { ...p, namespaceId, namespaceName } : p
    ));

    try {
      await namespaceApi.movePipeline(pipelineId, namespaceId);
    } catch (e) {
      // Revert on error
      setPipelines(prev => prev.map(p =>
        p.id === pipelineId ? { ...p, namespaceId: pipeline.namespaceId, namespaceName: pipeline.namespaceName } : p
      ));
      console.error('Move failed:', e);
    }

    setDraggingPipelineId(null);
  }, [pipelines]);

  /* --- Toggle namespace filter --- */
  const toggleNamespace = (nsId) => {
    setSelectedNamespaces(prev =>
      prev.includes(nsId) ? prev.filter(id => id !== nsId) : [...prev, nsId]
    );
  };

  /* --- Metrics --- */
  const counts = {
    total: pipelines.length,
    running: pipelines.filter(p => p.status === 'RUNNING').length,
    errored: pipelines.filter(p => p.status === 'ERRORED').length,
    completed: pipelines.filter(p => p.status === 'COMPLETED').length,
  };

  return (
    <div>
      <PageHeader
        title={PIPELINE.title}
        subtitle={PIPELINE.subtitle}
        actions={<Button onClick={() => navigate('/pipelines/new')}>{PIPELINE.newPipeline}</Button>}
      />

      {/* Metric cards */}
      <div style={{ ...FRSC, gap: SPACING.sm, marginBottom: SPACING.lg }}>
        <MetricCard label="Total pipelines" value={counts.total} />
        <MetricCard label="Running" value={counts.running} color={COLORS.status.success} />
        <MetricCard label="Errored" value={counts.errored} color={COLORS.status.errorDark} />
        <MetricCard label="Completed" value={counts.completed} color={COLORS.brand.primary} />
      </div>

      {/* Search bar */}
      <div style={{ marginBottom: SPACING.sm }}>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search by name, source, target, status, owner..."
          style={{
            width: '100%', padding: `${SPACING.xs} ${SPACING.md}`,
            border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.md,
            fontSize: FONT.size.md, boxSizing: 'border-box',
            background: COLORS.background.primary,
          }}
        />
      </div>

      {/* Namespace filter chips */}
      {namespaces.length > 0 && (
        <div style={{ ...FRSC, gap: '6px', marginBottom: SPACING.md, flexWrap: 'wrap' }}>
          <span style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary, marginRight: '2px' }}>Namespaces:</span>
          {namespaces.map(ns => {
            const isSelected = selectedNamespaces.includes(ns.id);
            return (
              <span
                key={ns.id}
                onClick={() => toggleNamespace(ns.id)}
                style={{
                  fontSize: FONT.size.xs, padding: '3px 12px', borderRadius: BORDER_RADIUS.pill,
                  cursor: 'pointer', fontWeight: isSelected ? FONT.weight.medium : FONT.weight.regular,
                  background: isSelected ? ns.color + '20' : COLORS.background.secondary,
                  color: isSelected ? ns.color : COLORS.text.secondary,
                  border: isSelected ? `1.5px solid ${ns.color}` : `1px solid ${COLORS.border.light}`,
                  transition: 'all 0.15s',
                }}
              >
                {ns.name} ({ns.pipelineCount})
              </span>
            );
          })}
          {/* + Create namespace button */}
          <span
            onClick={() => setShowCreateNs(true)}
            title="Create new namespace"
            style={{
              fontSize: FONT.size.xs, padding: '3px 10px', borderRadius: BORDER_RADIUS.pill,
              cursor: 'pointer', fontWeight: FONT.weight.medium,
              background: COLORS.background.secondary, color: COLORS.brand.primary,
              border: `1px dashed ${COLORS.brand.primary}`,
              display: 'flex', alignItems: 'center', gap: '3px',
              transition: 'all 0.15s',
            }}
            onMouseEnter={e => { e.currentTarget.style.background = COLORS.accent.purpleLight; }}
            onMouseLeave={e => { e.currentTarget.style.background = COLORS.background.secondary; }}
          >
            <span style={{ fontSize: '13px', lineHeight: 1 }}>+</span>
          </span>
          {selectedNamespaces.length > 0 && (
            <span
              onClick={() => setSelectedNamespaces([])}
              style={{
                fontSize: FONT.size.xs, color: COLORS.text.tertiary, cursor: 'pointer',
                textDecoration: 'underline', marginLeft: '4px',
              }}
            >
              Clear filters
            </span>
          )}
        </div>
      )}

      {/* Drag hint */}
      {draggingPipelineId && (
        <div style={{
          padding: `${SPACING.xxs} ${SPACING.sm}`, marginBottom: SPACING.xs,
          fontSize: FONT.size.xs, color: COLORS.text.tertiary, textAlign: 'center',
        }}>
          Drag pipeline to a namespace group header to move it
        </div>
      )}

      {/* Pipeline list grouped by namespace */}
      {filteredPipelines.length === 0 && !draggingPipelineId ? (
        <div style={{
          padding: '40px', textAlign: 'center', color: COLORS.text.tertiary,
          border: `1px dashed ${COLORS.border.medium}`, borderRadius: BORDER_RADIUS.lg,
        }}>
          {search || selectedNamespaces.length > 0
            ? 'No pipelines match your search or filters'
            : 'No pipelines yet. Create your first pipeline to get started.'}
        </div>
      ) : (
        groupedPipelines.map(group => (
          <NamespaceGroup
            key={group.namespace.id}
            namespace={group.namespace}
            pipelines={group.pipelines}
            navigate={navigate}
            onDragStart={setDraggingPipelineId}
            onDropPipeline={handleDropPipeline}
            dragOverNs={dragOverNs}
            setDragOverNs={setDragOverNs}
          />
        ))
      )}

      {/* Create Namespace Modal */}
      {showCreateNs && (
        <CreateNamespaceModal
          onClose={() => setShowCreateNs(false)}
          onCreated={(newNs) => setNamespaces(prev => [...prev, newNs])}
        />
      )}
    </div>
  );
};

export default PipelineDashboard;