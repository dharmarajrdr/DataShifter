import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { COLORS, FONT, SPACING, BORDER_RADIUS } from '../constants/design';
import { FRSC, FRBC } from '../constants/layouts';
import { PageHeader, Button, Chip } from '../components/common';
import { useAuth } from '../contexts/AuthContext';
import { authApi } from '../services/authApi';

const inputStyle = {
  width: '100%', padding: '8px 10px', border: `1px solid ${COLORS.border.light}`,
  borderRadius: BORDER_RADIUS.md, fontSize: FONT.size.md, boxSizing: 'border-box',
};

const Avatar = ({ initials, color, size = 32 }) => (
  <div style={{
    width: size, height: size, borderRadius: '50%', flexShrink: 0,
    background: color || COLORS.brand.primary,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: Math.round(size * 0.4), fontWeight: 500, color: '#fff',
  }}>{initials || '?'}</div>
);

const SectionTitle = ({ title, subtitle, action }) => (
  <div style={{ ...FRBC, marginBottom: SPACING.md }}>
    <div>
      <p style={{ fontSize: FONT.size.base, fontWeight: FONT.weight.medium }}>{title}</p>
      {subtitle && <p style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, marginTop: '2px' }}>{subtitle}</p>}
    </div>
    {action}
  </div>
);

const Divider = () => <div style={{ height: '1px', background: COLORS.border.light, margin: `${SPACING.xl} 0` }} />;

const OrgSettingsPage = () => {
  const { user, hasPermission } = useAuth();
  const [members, setMembers] = useState([]);
  const [roles, setRoles] = useState([]);
  const [invitations, setInvitations] = useState([]);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRoleId, setInviteRoleId] = useState('');
  const [inviting, setInviting] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const canManageMembers = hasPermission('org:manage_members');
  const canManageInvites = hasPermission('org:manage_invites');

  useEffect(() => {
    authApi.getMembers().then(res => setMembers(res.data || []));
    authApi.getRoles().then(res => setRoles(res.data || []));
    if (canManageInvites) {
      authApi.getInvitations().then(res => setInvitations(res.data || []));
    }
  }, [canManageInvites]);

  const handleInvite = async () => {
    if (!inviteEmail.trim()) return;
    setInviting(true);
    setError(null);
    try {
      await authApi.sendInvite({ email: inviteEmail, roleId: inviteRoleId || undefined });
      setInviteEmail('');
      authApi.getInvitations().then(res => setInvitations(res.data || []));
    } catch (err) {
      setError(err.message);
    } finally {
      setInviting(false);
    }
  };

  const handleInvitationAction = async (id, action) => {
    await authApi.handleInvitation(id, action);
    setInvitations(prev => prev.filter(i => i.id !== id));
    if (action === 'ACCEPT') {
      authApi.getMembers().then(res => setMembers(res.data || []));
    }
  };

  const handleRoleChange = async (userId, newRoleId) => {
    await authApi.updateMember(userId, { roleId: newRoleId });
    setMembers(prev => prev.map(m =>
      m.id === userId ? { ...m, roleId: newRoleId, roleName: roles.find(r => r.id === newRoleId)?.name } : m
    ));
  };

  return (
    <div>
      <PageHeader
        title="Organization settings"
        subtitle={user?.orgName || 'Your organization'}
        actions={
          hasPermission('org:manage_roles') && (
            <Button variant="secondary" onClick={() => navigate('/settings/roles')}>Manage roles</Button>
          )
        }
      />

      <div style={{ maxWidth: '680px' }}>

        {/* Org info */}
        <SectionTitle title="Organization" subtitle="Basic information about your org" />
        <div style={{
          padding: SPACING.lg, background: COLORS.background.primary,
          border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.lg,
        }}>
          <div style={{ ...FRSC, gap: SPACING.md }}>
            <div style={{
              width: 48, height: 48, borderRadius: BORDER_RADIUS.md,
              background: COLORS.brand.primaryLight, display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '20px', fontWeight: 500, color: COLORS.brand.primary,
            }}>
              {user?.orgName?.charAt(0)?.toUpperCase() || 'O'}
            </div>
            <div>
              <p style={{ fontSize: FONT.size.lg, fontWeight: FONT.weight.medium }}>{user?.orgName}</p>
              <p style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary, marginTop: '2px' }}>
                {members.length} member{members.length !== 1 ? 's' : ''} · {roles.length} roles
              </p>
            </div>
          </div>
        </div>

        <Divider />

        {/* Members */}
        <SectionTitle title="Members" subtitle={`${members.length} member${members.length !== 1 ? 's' : ''} in your organization`} />
        <div style={{
          border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.lg,
          overflow: 'hidden',
        }}>
          {members.map((member, i) => (
            <div key={member.id} style={{
              ...FRBC, padding: `${SPACING.sm} ${SPACING.md}`,
              borderTop: i > 0 ? `1px solid ${COLORS.border.light}` : 'none',
              background: COLORS.background.primary,
            }}>
              <div style={{ ...FRSC, gap: SPACING.sm }}>
                <Avatar initials={member.displayInitials} color={member.avatarColor} />
                <div>
                  <p style={{ fontSize: FONT.size.md, fontWeight: FONT.weight.medium, margin: 0 }}>
                    {member.fullName}
                    {member.id === user?.id && (
                      <span style={{ fontSize: FONT.size.xs, color: COLORS.text.tertiary, marginLeft: '6px' }}>(you)</span>
                    )}
                  </p>
                  <p style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary, margin: 0 }}>{member.email}</p>
                </div>
              </div>
              <div style={{ ...FRSC, gap: SPACING.xs }}>
                {canManageMembers && member.id !== user?.id ? (
                  <select
                    value={member.roleId || ''}
                    onChange={e => handleRoleChange(member.id, e.target.value)}
                    style={{
                      padding: '4px 8px', border: `1px solid ${COLORS.border.light}`,
                      borderRadius: BORDER_RADIUS.sm, fontSize: FONT.size.xs,
                      background: COLORS.background.primary, cursor: 'pointer',
                    }}
                  >
                    {roles.map(r => (
                      <option key={r.id} value={r.id}>{r.name}</option>
                    ))}
                  </select>
                ) : (
                  <Chip label={member.roleName || 'No role'} colorScheme="purple" />
                )}
                {!member.active && (
                  <span style={{ fontSize: FONT.size.xs, color: COLORS.status.errorDark }}>Disabled</span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Invite */}
        {canManageInvites && (
          <>
            <Divider />
            <SectionTitle title="Invite members" subtitle="Send an invite link via email" />
            <div style={{
              padding: SPACING.md, background: COLORS.background.primary,
              border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.lg,
            }}>
              <div style={{ ...FRSC, gap: SPACING.sm }}>
                <input value={inviteEmail} onChange={e => setInviteEmail(e.target.value)}
                  style={{ ...inputStyle, flex: 1 }} placeholder="colleague@company.com" type="email" />
                <select
                  value={inviteRoleId} onChange={e => setInviteRoleId(e.target.value)}
                  style={{
                    padding: '8px 10px', border: `1px solid ${COLORS.border.light}`,
                    borderRadius: BORDER_RADIUS.md, fontSize: FONT.size.sm, background: COLORS.background.primary,
                  }}
                >
                  <option value="">Select role</option>
                  {roles.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                </select>
                <Button onClick={handleInvite} style={inviting ? { opacity: 0.6 } : {}}>
                  {inviting ? 'Sending...' : 'Send invite'}
                </Button>
              </div>
              {error && (
                <p style={{ fontSize: FONT.size.xs, color: COLORS.status.errorDark, marginTop: SPACING.xs }}>{error}</p>
              )}
            </div>
          </>
        )}

        {/* Pending invitations / access requests */}
        {canManageInvites && invitations.length > 0 && (
          <>
            <Divider />
            <SectionTitle title="Pending" subtitle="Invitations and access requests awaiting action" />
            <div style={{
              border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.lg, overflow: 'hidden',
            }}>
              {invitations.map((inv, i) => (
                <div key={inv.id} style={{
                  ...FRBC, padding: `${SPACING.sm} ${SPACING.md}`,
                  borderTop: i > 0 ? `1px solid ${COLORS.border.light}` : 'none',
                  background: COLORS.background.primary,
                }}>
                  <div>
                    <p style={{ fontSize: FONT.size.md, margin: 0 }}>
                      {inv.email}
                      <Chip label={inv.inviteType === 'REQUEST' ? 'Request' : 'Invited'}
                        colorScheme={inv.inviteType === 'REQUEST' ? 'warning' : 'teal'}
                        style={{ marginLeft: '8px' }} />
                    </p>
                    <p style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary, margin: 0, marginTop: '2px' }}>
                      {inv.roleName && `Role: ${inv.roleName} · `}
                      {inv.invitedByName && `Invited by ${inv.invitedByName} · `}
                      {inv.createdAt && new Date(inv.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  {inv.inviteType === 'REQUEST' && (
                    <div style={{ ...FRSC, gap: '6px' }}>
                      <Button size="sm" onClick={() => handleInvitationAction(inv.id, 'ACCEPT')}>Approve</Button>
                      <Button variant="danger" size="sm" onClick={() => handleInvitationAction(inv.id, 'REJECT')}>Reject</Button>
                    </div>
                  )}
                  {inv.inviteType === 'INVITE' && (
                    <span style={{ fontSize: FONT.size.xs, color: COLORS.text.tertiary }}>Pending</span>
                  )}
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default OrgSettingsPage;