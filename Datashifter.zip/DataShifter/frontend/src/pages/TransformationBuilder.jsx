import React, { useState, useCallback, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { COLORS, FONT, SPACING, BORDER_RADIUS } from '../constants/design';
import { FRSC, FRBC, FREC, FRWSC } from '../constants/layouts';
import { TRANSFORM } from '../constants/literals';
import { PageHeader, Button } from '../components/common';
import { CloseIcon } from '../components/layout/Icons';
import { MOCK_TRANSFORM, AVAILABLE_FUNCTIONS } from '../services/api';

/* ================================================================
   FUNCTION METADATA — descriptions + whether args are needed
   ================================================================ */
const FN_META = {
  TRIM:            { desc: 'Remove leading/trailing whitespace', needsArgs: false },
  TO_STRING:       { desc: 'Convert value to string', needsArgs: false },
  TO_DATE:         { desc: 'Parse string to date', needsArgs: true, argHint: "format, e.g. 'yyyy-MM-dd'" },
  TO_NUMBER:       { desc: 'Parse string to number', needsArgs: false },
  CONCAT:          { desc: 'Append a suffix string', needsArgs: true, argHint: "suffix, e.g. '_suffix'" },
  SUBSTRING:       { desc: 'Extract substring by position', needsArgs: true, argHint: 'start,end  e.g. 0,10' },
  DEFAULT_IF_NULL: { desc: 'Replace null with default value', needsArgs: true, argHint: "default value, e.g. 'N/A'" },
  UPPER:           { desc: 'Convert to uppercase', needsArgs: false },
  LOWER:           { desc: 'Convert to lowercase', needsArgs: false },
};

/* ================================================================
   STEP COLOR CYCLE
   ================================================================ */
const STEP_COLORS = [
  { bg: '#EEEDFE', text: '#3C3489' },
  { bg: '#E1F5EE', text: '#085041' },
  { bg: '#FAECE7', text: '#712B13' },
  { bg: '#FBEAF0', text: '#72243E' },
  { bg: '#E6F1FB', text: '#0C447C' },
];

/* ================================================================
   SIMPLE CLIENT-SIDE TRANSFORM SIMULATOR — for live preview
   ================================================================ */
const simulateTransform = (value, fn, args) => {
  if (value === null || value === 'null') {
    if (fn === 'DEFAULT_IF_NULL') return args ? args.replace(/'/g, '') : '';
    return null;
  }
  const s = String(value).replace(/^"|"$/g, '');
  switch (fn) {
    case 'TRIM': return s.trim();
    case 'TO_STRING': return s;
    case 'UPPER': return s.toUpperCase();
    case 'LOWER': return s.toLowerCase();
    case 'TO_DATE': {
      const trimmed = s.trim();
      const d = new Date(trimmed);
      return isNaN(d.getTime()) ? '!!ERROR' : trimmed;
    }
    case 'TO_NUMBER': {
      const n = Number(s.trim());
      return isNaN(n) ? '!!ERROR' : n;
    }
    case 'CONCAT': return s + (args ? args.replace(/'/g, '') : '');
    case 'SUBSTRING': {
      const parts = (args || '0').split(',').map(p => parseInt(p.trim(), 10));
      return s.substring(parts[0] || 0, parts[1] !== undefined ? parts[1] : s.length);
    }
    case 'DEFAULT_IF_NULL': return s;
    default: return s;
  }
};

const simulateChain = (sourceValue, steps) => {
  const intermediates = [];
  let current = sourceValue;
  for (const step of steps) {
    current = simulateTransform(current, step.fn, step.args);
    intermediates.push(current);
    if (current === '!!ERROR') break;
  }
  return { intermediates, final: current };
};

/* ================================================================
   DRAGGABLE STEP CARD
   ================================================================ */
const StepCard = ({ step, index, totalSteps, onRemove, onArgsChange, dragHandlers }) => {
  const colors = STEP_COLORS[index % STEP_COLORS.length];
  const meta = FN_META[step.fn] || { desc: '', needsArgs: false };

  return (
    <div
      draggable
      {...dragHandlers(index)}
      style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: `10px ${SPACING.md}`,
        background: COLORS.background.secondary,
        cursor: 'grab', userSelect: 'none',
      }}
    >
      <div style={{ ...FRSC, gap: '8px', flex: 1, minWidth: 0 }}>
        {/* Grab handle */}
        <span style={{ color: COLORS.text.tertiary, fontSize: '14px', cursor: 'grab' }}>☰</span>
        {/* Step number */}
        <span style={{
          background: colors.bg, color: colors.text,
          fontSize: FONT.size.xs, padding: '2px 8px', borderRadius: BORDER_RADIUS.sm,
          fontWeight: FONT.weight.medium, flexShrink: 0,
        }}>Step {index + 1}</span>
        {/* Function name */}
        <span style={{ fontSize: FONT.size.md, fontWeight: FONT.weight.medium, fontFamily: 'monospace', flexShrink: 0 }}>
          {step.fn}
        </span>
        {/* Inline args editor */}
        {meta.needsArgs ? (
          <input
            value={step.args}
            onChange={e => onArgsChange(step.id, e.target.value)}
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
            placeholder={meta.argHint}
            style={{
              flex: 1, minWidth: '80px', maxWidth: '180px',
              padding: '3px 8px', border: `1px solid ${COLORS.border.light}`,
              borderRadius: BORDER_RADIUS.sm, fontSize: FONT.size.xs,
              fontFamily: 'monospace', color: COLORS.brand.primary,
              background: COLORS.background.primary,
            }}
            draggable={false}
          />
        ) : (
          <span style={{ fontSize: FONT.size.xs, color: COLORS.text.tertiary, fontStyle: 'italic' }}>
            {meta.desc}
          </span>
        )}
      </div>
      {/* Remove */}
      <span
        onClick={(e) => { e.stopPropagation(); onRemove(step.id); }}
        style={{ cursor: 'pointer', marginLeft: 8, flexShrink: 0 }}
      >
        <CloseIcon color={COLORS.text.tertiary} size={12} />
      </span>
    </div>
  );
};

/* ================================================================
   MAIN — TransformationBuilder
   ================================================================ */
const TransformationBuilder = () => {
  const [data] = useState(MOCK_TRANSFORM);
  const [steps, setSteps] = useState(MOCK_TRANSFORM.steps);
  const [dragIdx, setDragIdx] = useState(null);
  const [overIdx, setOverIdx] = useState(null);
  const [hasChanges, setHasChanges] = useState(false);
  const navigate = useNavigate();
  const { pipelineId } = useParams();

  /* --- Mutations --- */
  const removeStep = useCallback((id) => {
    setSteps(prev => prev.filter(s => s.id !== id));
    setHasChanges(true);
  }, []);

  const addStep = useCallback((fn) => {
    const meta = FN_META[fn] || {};
    setSteps(prev => [...prev, {
      id: `s${Date.now()}`,
      fn,
      args: '',
      description: meta.desc || `Apply ${fn}`,
    }]);
    setHasChanges(true);
  }, []);

  const updateArgs = useCallback((id, args) => {
    setSteps(prev => prev.map(s => s.id === id ? { ...s, args } : s));
    setHasChanges(true);
  }, []);

  /* --- Drag reorder --- */
  const dragHandlers = useCallback((idx) => ({
    onDragStart: (e) => {
      setDragIdx(idx);
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', idx.toString());
      setTimeout(() => e.target.style.opacity = '0.4', 0);
    },
    onDragEnd: (e) => {
      e.target.style.opacity = '1';
      setDragIdx(null);
      setOverIdx(null);
    },
    onDragOver: (e) => {
      e.preventDefault();
      if (dragIdx !== null && dragIdx !== idx) setOverIdx(idx);
    },
    onDrop: (e) => {
      e.preventDefault();
      if (dragIdx === null || dragIdx === idx) return;
      setSteps(prev => {
        const next = [...prev];
        const [moved] = next.splice(dragIdx, 1);
        next.splice(idx, 0, moved);
        return next;
      });
      setDragIdx(null);
      setOverIdx(null);
      setHasChanges(true);
    },
  }), [dragIdx]);

  /* --- Live preview simulation --- */
  const sampleValues = useMemo(() => {
    return data.preview.map(row => row.source);
  }, [data.preview]);

  const previewResults = useMemo(() => {
    return sampleValues.map(src => {
      const raw = src === 'null' ? null : src;
      const result = simulateChain(raw, steps);
      return {
        source: src,
        intermediates: result.intermediates,
        final: result.final,
        isError: result.final === '!!ERROR' || result.final === null,
      };
    });
  }, [sampleValues, steps]);

  const errorCount = previewResults.filter(r => r.isError).length;

  return (
    <div>
      <PageHeader
        breadcrumbs={[
          { label: 'Orders migration', onClick: () => navigate(`/pipelines/${pipelineId}/mapping`) },
          { label: 'Column mapping', onClick: () => navigate(`/pipelines/${pipelineId}/mapping`) },
          { label: TRANSFORM.title },
        ]}
      />

      <div style={{
        background: COLORS.background.primary, border: `1px solid ${COLORS.border.light}`,
        borderRadius: BORDER_RADIUS.lg, overflow: 'hidden', maxWidth: '75%',
      }}>
        {/* Header */}
        <div style={{ padding: `${SPACING.md} ${SPACING.lg}`, borderBottom: `1px solid ${COLORS.border.light}` }}>
          <p style={{ fontSize: FONT.size.lg, fontWeight: FONT.weight.medium }}>{TRANSFORM.title}</p>
          <p style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary, marginTop: '3px' }}>
            {data.sourceColumn} ({data.sourceType}) → {data.targetColumn} ({data.targetType})
          </p>
        </div>

        <div style={{ padding: SPACING.lg }}>

          {/* ===== Function chain (drag-to-reorder) ===== */}
          <div style={{ marginBottom: SPACING.lg }}>
            <p style={{ fontSize: FONT.size.xs, fontWeight: FONT.weight.medium, color: COLORS.text.secondary, marginBottom: SPACING.xs }}>
              {TRANSFORM.functionChain}
            </p>

            {steps.length === 0 ? (
              <div style={{
                border: `1px dashed ${COLORS.border.medium}`, borderRadius: BORDER_RADIUS.md,
                padding: '24px', textAlign: 'center', color: COLORS.text.tertiary, fontSize: FONT.size.sm,
              }}>
                No functions added. Click a function below to start building the chain.
              </div>
            ) : (
              <div style={{ border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.md, overflow: 'hidden' }}>
                {steps.map((step, i) => (
                  <React.Fragment key={step.id}>
                    {i > 0 && (
                      <div style={{
                        display: 'flex', alignItems: 'center', gap: 6,
                        padding: `2px ${SPACING.md} 2px 42px`,
                        borderTop: overIdx === i && dragIdx !== i ? `2px solid ${COLORS.brand.primary}` : 'none',
                      }}>
                        <span style={{ fontSize: '12px', color: COLORS.text.tertiary }}>↓</span>
                        <span style={{ fontSize: '10px', color: COLORS.text.tertiary }}>then</span>
                      </div>
                    )}
                    <StepCard
                      step={step}
                      index={i}
                      totalSteps={steps.length}
                      onRemove={removeStep}
                      onArgsChange={updateArgs}
                      dragHandlers={dragHandlers}
                    />
                  </React.Fragment>
                ))}
              </div>
            )}
          </div>

          {/* ===== Available functions (click to add) ===== */}
          <div style={{ marginBottom: SPACING.lg }}>
            <p style={{ fontSize: FONT.size.xs, fontWeight: FONT.weight.medium, color: COLORS.text.secondary, marginBottom: SPACING.xs }}>
              {TRANSFORM.availableFunctions}
            </p>
            <div style={{ ...FRWSC, gap: '6px' }}>
              {AVAILABLE_FUNCTIONS.map(fn => {
                const meta = FN_META[fn] || {};
                return (
                  <div
                    key={fn}
                    onClick={() => addStep(fn)}
                    title={meta.desc}
                    style={{
                      background: COLORS.background.secondary, border: `1px solid ${COLORS.border.light}`,
                      padding: `${SPACING.xxs} 10px`, borderRadius: BORDER_RADIUS.md,
                      fontSize: FONT.size.xs, fontFamily: 'monospace', cursor: 'pointer',
                      transition: 'all 0.15s', display: 'flex', alignItems: 'center', gap: 4,
                    }}
                    onMouseEnter={e => {
                      e.currentTarget.style.background = COLORS.accent.purpleLight;
                      e.currentTarget.style.borderColor = COLORS.brand.primary;
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.background = COLORS.background.secondary;
                      e.currentTarget.style.borderColor = COLORS.border.light;
                    }}
                  >
                    <span>+</span>
                    <span>{fn}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ===== Live preview ===== */}
          <div style={{ marginBottom: SPACING.md }}>
            <div style={{ ...FRBC, marginBottom: SPACING.xs }}>
              <p style={{ fontSize: FONT.size.xs, fontWeight: FONT.weight.medium, color: COLORS.text.secondary }}>
                {TRANSFORM.livePreview}
              </p>
              <span style={{ fontSize: '10px', color: COLORS.text.tertiary }}>
                {steps.length} step{steps.length !== 1 ? 's' : ''} in chain
              </span>
            </div>
            <div style={{ border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.md, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: FONT.size.xs }}>
                <thead>
                  <tr style={{ background: COLORS.background.secondary }}>
                    <th style={{ textAlign: 'left', padding: '7px 10px', fontWeight: FONT.weight.medium, color: COLORS.text.secondary, width: '30%' }}>Source</th>
                    {steps.map((_, i) => (
                      <th key={i} style={{ textAlign: 'center', padding: '7px 10px', fontWeight: FONT.weight.medium, color: COLORS.text.secondary }}>
                        Step {i + 1}
                      </th>
                    ))}
                    <th style={{ textAlign: 'right', padding: '7px 10px', fontWeight: FONT.weight.medium, color: COLORS.text.secondary, width: '25%' }}>Final</th>
                  </tr>
                </thead>
                <tbody style={{ fontFamily: 'monospace' }}>
                  {previewResults.map((row, i) => (
                    <tr key={i} style={{
                      borderTop: `1px solid ${COLORS.border.light}`,
                      background: i % 2 === 1 ? COLORS.background.secondary : 'transparent',
                    }}>
                      <td style={{ padding: '6px 10px', color: COLORS.text.secondary }}>{row.source}</td>
                      {row.intermediates.map((val, si) => (
                        <td key={si} style={{
                          padding: '6px 10px', textAlign: 'center',
                          color: val === '!!ERROR' ? COLORS.status.errorDark : COLORS.text.primary,
                          fontSize: '10px',
                        }}>
                          {val === '!!ERROR' ? 'ERR' : val === null ? 'null' : String(val)}
                        </td>
                      ))}
                      <td style={{
                        padding: '6px 10px', textAlign: 'right', fontWeight: FONT.weight.medium,
                        color: row.isError ? COLORS.status.errorDark : COLORS.status.successDark,
                      }}>
                        {row.final === '!!ERROR' ? 'ERROR' : row.final === null ? 'null' : String(row.final)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Warning */}
            {errorCount > 0 && (
              <p style={{ fontSize: '10px', color: COLORS.status.warningDark, marginTop: '6px' }}>
                {errorCount} of {previewResults.length} sample rows will fail.
                {steps.some(s => s.fn === 'TO_DATE') && !steps.some(s => s.fn === 'DEFAULT_IF_NULL')
                  ? ' Consider adding DEFAULT_IF_NULL before TO_DATE.'
                  : ''}
              </p>
            )}

            {steps.length === 0 && (
              <p style={{ fontSize: '10px', color: COLORS.text.tertiary, marginTop: '6px' }}>
                Add functions above to see the live preview update.
              </p>
            )}
          </div>

          {/* ===== Actions ===== */}
          <div style={{ ...FRBC, paddingTop: SPACING.sm, borderTop: `1px solid ${COLORS.border.light}` }}>
            <span style={{ fontSize: FONT.size.xs, color: COLORS.text.tertiary }}>
              {hasChanges ? 'Unsaved changes' : ''}
            </span>
            <div style={{ ...FREC, gap: SPACING.xs }}>
              <Button variant="secondary" onClick={() => navigate(`/pipelines/${pipelineId}/mapping`)}>
                {TRANSFORM.cancel}
              </Button>
              <Button onClick={() => navigate(`/pipelines/${pipelineId}/mapping`)}>
                {TRANSFORM.apply}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TransformationBuilder;