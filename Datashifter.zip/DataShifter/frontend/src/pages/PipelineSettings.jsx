import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { COLORS, FONT, SPACING, BORDER_RADIUS } from '../constants/design';
import { FRSC, FRBC, FCSS } from '../constants/layouts';
import { SETTINGS } from '../constants/literals';
import { PageHeader, Button, Toggle, Chip } from '../components/common';
import { settingsApi } from '../services/api';

const SectionTitle = ({ title, subtitle }) => (
  <div style={{ marginBottom: SPACING.md }}>
    <p style={{ fontSize: FONT.size.base, fontWeight: FONT.weight.medium }}>{title}</p>
    <p style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, marginTop: '2px' }}>{subtitle}</p>
  </div>
);

const Divider = () => (
  <div style={{ height: '1px', background: COLORS.border.light, margin: `${SPACING.xl} 0` }} />
);

const SettingRow = ({ label, description, children }) => (
  <div style={{
    ...FRBC, padding: `${SPACING.sm} ${SPACING.md}`,
    background: COLORS.background.secondary, borderRadius: BORDER_RADIUS.md,
    marginBottom: SPACING.xs,
  }}>
    <div>
      <p style={{ fontSize: FONT.size.md, fontWeight: FONT.weight.medium }}>{label}</p>
      <p style={{ fontSize: FONT.size.xs, color: COLORS.text.secondary, marginTop: '2px' }}>{description}</p>
    </div>
    {children}
  </div>
);

const WriteModeSelector = ({ selected, onChange }) => {
  const modes = ['INSERT_ONLY', 'UPSERT', 'UPDATE_ONLY'];
  return (
    <div style={{ ...FRSC, gap: '6px' }}>
      {modes.map(mode => {
        const isActive = selected === mode;
        const info = SETTINGS.writeModes[mode];
        return (
          <div
            key={mode}
            onClick={() => onChange(mode)}
            style={{
              flex: 1, padding: '10px', textAlign: 'center', cursor: 'pointer',
              border: isActive ? `2px solid ${COLORS.brand.primary}` : `1px solid ${COLORS.border.light}`,
              borderRadius: BORDER_RADIUS.md,
              background: isActive ? COLORS.accent.purpleLight : COLORS.background.primary,
            }}
          >
            <p style={{
              fontSize: FONT.size.sm, fontWeight: FONT.weight.medium,
              color: isActive ? COLORS.accent.purpleText : COLORS.text.primary,
            }}>{info.label}</p>
            <p style={{
              fontSize: '10px', marginTop: '2px',
              color: isActive ? COLORS.brand.primary : COLORS.text.tertiary,
            }}>{info.desc}</p>
          </div>
        );
      })}
    </div>
  );
};

const WRITE_MODE_CHIP_COLORS = {
  INSERT_ONLY: 'teal',
  UPSERT: 'purple',
  UPDATE_ONLY: 'warning',
};

const PipelineSettings = () => {
  const [settings, setSettings] = useState(null);
  const { pipelineId } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    settingsApi.getByPipelineId(pipelineId).then(res => setSettings(res.data));
  }, [pipelineId]);

  if (!settings) return null;

  const update = (key, value) => setSettings({ ...settings, [key]: value });

  return (
    <div>
      <PageHeader
        breadcrumbs={[
          { label: settings.name, onClick: () => navigate(`/pipelines/${pipelineId}/monitor`) },
          { label: SETTINGS.title },
        ]}
        actions={<Button>{SETTINGS.save}</Button>}
      />

      <div style={{ maxWidth: '620px' }}>
        {/* General */}
        <SectionTitle title={SETTINGS.general.title} subtitle={SETTINGS.general.subtitle} />
        <div style={{ marginBottom: SPACING.md }}>
          <label style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, display: 'block', marginBottom: SPACING.xxs }}>
            {SETTINGS.general.name}
          </label>
          <input
            value={settings.name}
            onChange={e => update('name', e.target.value)}
            style={{
              width: '100%', padding: `${SPACING.xs} 10px`,
              border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.md,
              fontSize: FONT.size.md, boxSizing: 'border-box',
            }}
          />
        </div>
        <div style={{ marginBottom: SPACING.md }}>
          <label style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, display: 'block', marginBottom: SPACING.xxs }}>
            {SETTINGS.general.description}
          </label>
          <input
            value={settings.description}
            onChange={e => update('description', e.target.value)}
            style={{
              width: '100%', padding: `${SPACING.xs} 10px`,
              border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.md,
              fontSize: FONT.size.md, boxSizing: 'border-box',
            }}
          />
        </div>

        <Divider />

        {/* Processing */}
        <SectionTitle title={SETTINGS.processing.title} subtitle={SETTINGS.processing.subtitle} />
        <div style={{ marginBottom: SPACING.md }}>
          <label style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, display: 'block', marginBottom: SPACING.xxs }}>
            {SETTINGS.processing.chunkSize}
          </label>
          <div style={{ ...FRSC, gap: SPACING.sm }}>
            <input
              type="range" min="1000" max="50000" step="1000"
              value={settings.chunkSize}
              onChange={e => update('chunkSize', Number(e.target.value))}
              style={{ flex: 1 }}
            />
            <span style={{
              fontSize: FONT.size.md, fontWeight: FONT.weight.medium, fontFamily: 'monospace',
              minWidth: '60px', textAlign: 'right',
            }}>{settings.chunkSize.toLocaleString()}</span>
          </div>
          <p style={{ fontSize: FONT.size.xs, color: COLORS.text.tertiary, marginTop: SPACING.xxs }}>
            {SETTINGS.processing.chunkHint}
          </p>
        </div>
        <div style={{ marginBottom: SPACING.md }}>
          <label style={{ fontSize: FONT.size.sm, color: COLORS.text.secondary, display: 'block', marginBottom: SPACING.xs }}>
            {SETTINGS.processing.defaultWriteMode}
          </label>
          <WriteModeSelector selected={settings.defaultWriteMode} onChange={v => update('defaultWriteMode', v)} />
        </div>

        <Divider />

        {/* Error handling */}
        <SectionTitle title={SETTINGS.errorHandling.title} subtitle={SETTINGS.errorHandling.subtitle} />
        <SettingRow label={SETTINGS.errorHandling.ignoreExceptions} description={SETTINGS.errorHandling.ignoreExceptionsDesc}>
          <Toggle checked={settings.ignoreExceptions} onChange={v => update('ignoreExceptions', v)} />
        </SettingRow>
        <SettingRow label={SETTINGS.errorHandling.maxThreshold} description={SETTINGS.errorHandling.maxThresholdDesc}>
          <input
            type="number" value={settings.maxErrorThreshold}
            onChange={e => update('maxErrorThreshold', Number(e.target.value))}
            style={{
              width: '80px', padding: `${SPACING.xxs} ${SPACING.xs}`,
              border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.sm,
              fontSize: FONT.size.sm, textAlign: 'right', fontFamily: 'monospace',
            }}
          />
        </SettingRow>
        <SettingRow label={SETTINGS.errorHandling.logSourceRow} description={SETTINGS.errorHandling.logSourceRowDesc}>
          <Toggle checked={settings.logSourceRow} onChange={v => update('logSourceRow', v)} />
        </SettingRow>

        <Divider />

        {/* Per-table overrides */}
        <SectionTitle title={SETTINGS.perTable.title} subtitle={SETTINGS.perTable.subtitle} />
        <div style={{
          border: `1px solid ${COLORS.border.light}`, borderRadius: BORDER_RADIUS.md,
          overflow: 'hidden', background: COLORS.background.primary,
        }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: FONT.size.sm }}>
            <thead>
              <tr style={{ background: COLORS.background.secondary }}>
                <th style={{ textAlign: 'left', padding: `${SPACING.xs} ${SPACING.sm}`, fontWeight: FONT.weight.medium, color: COLORS.text.secondary }}>
                  {SETTINGS.perTable.targetTable}
                </th>
                <th style={{ textAlign: 'left', padding: `${SPACING.xs} ${SPACING.sm}`, fontWeight: FONT.weight.medium, color: COLORS.text.secondary }}>
                  {SETTINGS.perTable.writeMode}
                </th>
                <th style={{ textAlign: 'left', padding: `${SPACING.xs} ${SPACING.sm}`, fontWeight: FONT.weight.medium, color: COLORS.text.secondary }}>
                  {SETTINGS.perTable.override}
                </th>
              </tr>
            </thead>
            <tbody>
              {settings.tableOverrides.map(row => (
                <tr key={row.table} style={{ borderTop: `1px solid ${COLORS.border.light}` }}>
                  <td style={{ padding: `${SPACING.xs} ${SPACING.sm}`, fontWeight: FONT.weight.medium }}>{row.table}</td>
                  <td style={{ padding: `${SPACING.xs} ${SPACING.sm}` }}>
                    <Chip label={row.writeMode} colorScheme={WRITE_MODE_CHIP_COLORS[row.writeMode] || 'default'} />
                  </td>
                  <td style={{ padding: `${SPACING.xs} ${SPACING.sm}` }}>
                    {row.isOverride ? (
                      <span style={{ fontSize: FONT.size.xs, color: COLORS.brand.primary, cursor: 'pointer', textDecoration: 'underline' }}>Custom</span>
                    ) : (
                      <span style={{ fontSize: FONT.size.xs, color: COLORS.text.tertiary }}>Default</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PipelineSettings;
