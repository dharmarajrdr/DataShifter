/* ============================================================
   AUTH API — signup, login, refresh, org management
   
   These call auth-service endpoints via Gateway.
   Public endpoints use { skipAuth: true } to avoid injecting token.
   ============================================================ */

import { apiClient, USE_MOCK } from './apiClient';

const mockResponse = (data, message = 'Success') =>
  Promise.resolve({ message, data, info: null, status: 200 });

const MOCK_USER = {
  id: 'u-001', email: 'dharr@paypal.com', fullName: 'Dharmaraj R',
  displayInitials: 'DU', avatarColor: '#534AB7',
  orgId: 'org-001', orgName: 'Datashifter Inc.',
  roleId: 'role-001', roleName: 'Admin',
  effectivePermissions: [
    'pipeline:create', 'pipeline:view', 'pipeline:edit', 'pipeline:delete',
    'pipeline:run', 'pipeline:pause', 'pipeline:stop',
    'namespace:create', 'namespace:edit', 'namespace:delete',
    'connection:create', 'connection:edit', 'connection:delete',
    'connection:test', 'connection:browse_schema',
    'monitor:view', 'monitor:view_errors', 'settings:edit',
    'org:manage_members', 'org:manage_roles', 'org:manage_invites', 'org:view_audit',
  ],
  active: true, emailVerified: false,
};

const MOCK_TOKEN_RESPONSE = {
  accessToken: 'mock-access-token',
  refreshToken: 'mock-refresh-token',
  expiresIn: 900,
  tokenType: 'Bearer',
  user: MOCK_USER,
};

export const authApi = {

  signup: (payload) => USE_MOCK
    ? mockResponse({ ...MOCK_TOKEN_RESPONSE, user: { ...MOCK_USER, fullName: payload.fullName, email: payload.email } })
    : apiClient.post('/auth/signup', payload, { skipAuth: true }),

  login: (payload) => USE_MOCK
    ? mockResponse(MOCK_TOKEN_RESPONSE)
    : apiClient.post('/auth/login', payload, { skipAuth: true }),

  refresh: (payload) => USE_MOCK
    ? mockResponse(MOCK_TOKEN_RESPONSE)
    : apiClient.post('/auth/refresh', payload, { skipAuth: true }),

  me: () => USE_MOCK
    ? mockResponse(MOCK_USER)
    : apiClient.get('/auth/me'),

  updateProfile: (payload) => USE_MOCK
    ? mockResponse({ ...MOCK_USER, ...payload })
    : apiClient.put('/auth/me', payload),

  // Org management
  createOrg: (payload) => USE_MOCK
    ? mockResponse({ id: 'org-new', name: payload.name, slug: payload.name.toLowerCase().replace(/\s+/g, '-') })
    : apiClient.post('/auth/orgs', payload),

  requestAccess: (payload) => USE_MOCK
    ? mockResponse(null)
    : apiClient.post('/auth/request-access', payload),

  // Invitations (for org admins)
  getInvitations: () => USE_MOCK
    ? mockResponse([])
    : apiClient.get('/auth/invitations'),

  sendInvite: (payload) => USE_MOCK
    ? mockResponse({ id: 'inv-new', email: payload.email, status: 'PENDING' })
    : apiClient.post('/auth/invitations', payload),

  handleInvitation: (id, action) => USE_MOCK
    ? mockResponse(null)
    : apiClient.post(`/auth/invitations/${id}`, { action }),

  // Roles
  getRoles: () => USE_MOCK
    ? mockResponse([
        { id: 'role-001', name: 'Admin', description: 'Full access', system: true, permissions: [], memberCount: 1 },
        { id: 'role-002', name: 'Editor', description: 'Create and manage pipelines', system: true, permissions: [], memberCount: 2 },
        { id: 'role-003', name: 'Viewer', description: 'Read-only access', system: true, permissions: [], memberCount: 1 },
      ])
    : apiClient.get('/auth/roles'),

  createRole: (payload) => USE_MOCK
    ? mockResponse({ ...payload, id: 'role-new', system: false, memberCount: 0 })
    : apiClient.post('/auth/roles', payload),

  updateRole: (id, payload) => USE_MOCK
    ? mockResponse(payload)
    : apiClient.put(`/auth/roles/${id}`, payload),

  deleteRole: (id) => USE_MOCK
    ? mockResponse(null)
    : apiClient.delete(`/auth/roles/${id}`),

  // Members
  getMembers: () => USE_MOCK
    ? mockResponse([
        { ...MOCK_USER, roleName: 'Admin' },
        { id: 'u-002', email: 'keeraj@paypal.com', fullName: 'Keertiga Raj', displayInitials: 'KR', avatarColor: '#D4537E', roleName: 'Editor', active: true },
        { id: 'u-003', email: 'hmanivannan@paypal.com', fullName: 'Harisudhan Manivannan', displayInitials: 'HM', avatarColor: '#1D9E75', roleName: 'Viewer', active: true },
      ])
    : apiClient.get('/auth/members'),

  updateMember: (userId, payload) => USE_MOCK
    ? mockResponse(null)
    : apiClient.put(`/auth/members/${userId}`, payload),
};