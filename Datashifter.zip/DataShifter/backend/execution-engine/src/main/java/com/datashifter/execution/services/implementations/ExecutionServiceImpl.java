package com.datashifter.execution.services.implementations;

import com.datashifter.common.enums.*;
import com.datashifter.common.events.KafkaTopics;
import com.datashifter.common.events.PipelineEvents.*;
import com.datashifter.common.exceptions.DatashifterException;
import com.datashifter.common.exceptions.ResourceNotFoundException;
import com.datashifter.common.models.*;
import com.datashifter.common.utils.EncryptionUtil;
import com.datashifter.connector.spi.interfaces.ConnectionConfig;
import com.datashifter.connector.spi.interfaces.DatabaseConnector;
import com.datashifter.connector.spi.interfaces.WriteResult;
import com.datashifter.execution.checkpoint.CheckpointManager;
import com.datashifter.execution.checkpoint.CheckpointManager.Checkpoint;
import com.datashifter.execution.consumers.PipelineJobConsumer;
import com.datashifter.execution.contexts.ExecutionContext;
import com.datashifter.execution.contexts.ExecutionContext.ResolvedColumnMapping;
import com.datashifter.execution.contexts.ExecutionContext.TargetTableContext;
import com.datashifter.execution.repositories.ExecutionConnectionRepository;
import com.datashifter.execution.repositories.ExecutionPipelineRepository;
import com.datashifter.execution.services.interfaces.ExecutionService;
import com.datashifter.execution.strategies.filters.FilterChain;
import com.datashifter.execution.strategies.filters.RowFilter;
import com.datashifter.execution.services.implementations.ColumnMappingResolver;
import com.datashifter.execution.strategies.transformers.TransformerFactory;
import com.datashifter.connector.factories.ConnectorFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import com.datashifter.execution.strategies.writers.WriteStrategyExecutor;
import com.datashifter.execution.parallel.ParallelChunkProcessor;
import com.datashifter.execution.parallel.ParallelConfig;
import com.datashifter.execution.parallel.ChunkSizeTuner;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ExecutionServiceImpl implements ExecutionService {

    private final ExecutionPipelineRepository pipelineRepo;
    private final ExecutionConnectionRepository connectionRepo;
    private final ConnectorFactory connectorFactory;
    private final TransformerFactory transformerFactory;
    private final CheckpointManager checkpointManager;
    private final ColumnMapperService columnMapperService;
    private final WriteStrategyExecutor writeStrategyExecutor;
    private final InFlightBufferService inFlightBuffer;
    private final ColumnMappingResolver columnMappingResolver;
    private final PipelineJobConsumer jobConsumer;
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final ObjectMapper objectMapper;
    private final ChunkSizeTuner chunkSizeTuner;
    private final ParallelChunkProcessor parallelChunkProcessor;
    private final ParallelConfig parallelConfig;

    @Override
    public void execute(String pipelineId, String executionLogId) {
        log.info("=== Starting pipeline execution: {} ===", pipelineId);

        // 1. Load full pipeline graph
        Pipeline pipeline = pipelineRepo.findByIdWithFullGraph(pipelineId)
                .orElseThrow(() -> new ResourceNotFoundException("Pipeline", pipelineId));

        // 2. Build execution context
        ExecutionContext ctx = buildContext(pipeline, executionLogId);

        // 3. Publish RUNNING status
        publishStatus(ctx, PipelineStatus.VALIDATED, PipelineStatus.RUNNING, "Execution started");

        try {
            // 4. Table loop — sequential, user-defined order
            executeTableLoop(ctx);

            // 5. If we reached here without pause/stop — completed
            log.info("=== Pipeline completed: {} | Rows: {} | Errors: {} ===",
                    pipelineId, ctx.getTotalRowsProcessed().get(), ctx.getTotalErrors().get());
            publishStatus(ctx, PipelineStatus.RUNNING, PipelineStatus.COMPLETED, "All tables migrated");
            inFlightBuffer.clear(pipelineId);

        } catch (PipelinePausedException e) {
            log.info("Pipeline paused: {} at table {} chunk {}",
                    pipelineId, ctx.getCurrentTableName(), ctx.getCurrentChunkNumber());
            publishStatus(ctx, PipelineStatus.RUNNING, PipelineStatus.PAUSED, e.getMessage());

        } catch (PipelineStoppedException e) {
            log.info("Pipeline stopped by user: {}", pipelineId);
            publishStatus(ctx, PipelineStatus.RUNNING, PipelineStatus.ERRORED, "Stopped by user");
            inFlightBuffer.clear(pipelineId);

        } catch (Exception e) {
            log.error("Pipeline failed: {} — {}", pipelineId, e.getMessage(), e);
            publishStatus(ctx, PipelineStatus.RUNNING, PipelineStatus.ERRORED, e.getMessage());
            inFlightBuffer.clear(pipelineId);
        }
    }

    // =========================================================================
    // TABLE LOOP
    // =========================================================================

    private void executeTableLoop(ExecutionContext ctx) {

        // Restore progress counters from checkpoints (resume scenario)
        long previousRows = checkpointManager.getTotalRowsFromCheckpoints(ctx.getPipelineId());
        if (previousRows > 0) {
            ctx.getTotalRowsProcessed().set(previousRows);
            log.info("Resumed with {} previously processed rows", previousRows);
        }

        List<PipelineTable> tables = ctx.getPipeline().getPipelineTables();
        long totalRowsAllTables = estimateTotalRows(ctx, tables);

        for (int i = 0; i < tables.size(); i++) {
            PipelineTable pt = tables.get(i);
            ctx.setCurrentTableIndex(i);
            ctx.setCurrentTableName(pt.getSourceTable());

            // Check if this table was already completed (resume scenario)
            Checkpoint cp = checkpointManager.loadCheckpoint(ctx.getPipelineId(), pt.getSourceTable());
            if (cp != null && cp.getLastCommittedChunk() == -1) {
                log.info("Table {} already completed, skipping", pt.getSourceTable());
                continue;
            }

            log.info("--- Processing table {}/{}: {} ---", i + 1, tables.size(), pt.getSourceTable());

            // Execute chunk loop for this table
            executeChunkLoop(ctx, pt, cp, totalRowsAllTables);

            // Mark table as completed in checkpoint (chunk = -1 sentinel)
            checkpointManager.forceCheckpoint(Checkpoint.builder()
                    .pipelineId(ctx.getPipelineId())
                    .tableName(pt.getSourceTable())
                    .currentTableIndex(i)
                    .lastCommittedChunk(-1)  // sentinel: table done
                    .rowsProcessed(ctx.getTotalRowsProcessed().get())
                    .timestamp(Instant.now())
                    .build());
        }
    }

    // =========================================================================
    // CHUNK LOOP — the inner heart
    // =========================================================================

    private void executeChunkLoop(ExecutionContext ctx, PipelineTable pt,
                                   Checkpoint resumeCheckpoint, long totalRowsAllTables) {

        DatabaseConnector sourceConnector = connectorFactory.getConnector(ctx.getSourceConfig().getDbType());
        DatabaseConnector targetConnector = connectorFactory.getConnector(ctx.getTargetConfig().getDbType());

         int workerCount = parallelConfig.resolveWorkerCount(ctx.getPipeline().getParallelWorkers());

        if (workerCount > 1) {
            // Parallel path
            parallelChunkProcessor.process(ctx, pt, sourceConnector, targetConnector, resumeCheckpoint, totalRowsAllTables, workerCount);
            return;
        }

        String pkColumn = sourceConnector.getPrimaryKeyColumn(ctx.getSourceConfig(), pt.getSourceTable());
        
        // int chunkSize = ctx.getPipeline().getChunkSize();
        ChunkSizeTuner.TuningResult tuning = chunkSizeTuner.tune(sourceConnector, ctx.getSourceConfig(), pt.getSourceTable(), ctx.getPipeline().getChunkSize());
        int chunkSize = tuning.getRecommendedChunkSize();

        // Resume: pick up from last committed PK
        String lastPkValue = (resumeCheckpoint != null) ? resumeCheckpoint.getLastCommittedPk() : null;
        long chunkNumber = (resumeCheckpoint != null) ? resumeCheckpoint.getLastCommittedChunk() + 1 : 0;

        // Get pre-built filter chain for this table
        FilterChain filterChain = ctx.getFilterChains().getOrDefault(pt.getId(), new FilterChain(List.of()));

        while (true) {
            // --- Check for pause/stop commands ---
            if (jobConsumer.isPauseRequested(ctx.getPipelineId())) {
                // Save checkpoint and throw to unwind
                saveCurrentCheckpoint(ctx, pt.getSourceTable(), chunkNumber - 1, lastPkValue);
                jobConsumer.clearCommand(ctx.getPipelineId());
                throw new PipelinePausedException("Paused after chunk " + (chunkNumber - 1));
            }
            if (jobConsumer.isStopRequested(ctx.getPipelineId())) {
                saveCurrentCheckpoint(ctx, pt.getSourceTable(), chunkNumber - 1, lastPkValue);
                jobConsumer.clearCommand(ctx.getPipelineId());
                throw new PipelineStoppedException("Stopped by user");
            }

            ctx.setCurrentChunkNumber(chunkNumber);

            // --- STEP 1: READ chunk from source ---
            List<Map<String, Object>> sourceRecords = sourceConnector.readChunk(
                    ctx.getSourceConfig(), pt.getSourceTable(), pkColumn, lastPkValue, chunkSize);

            if (sourceRecords.isEmpty()) {
                log.info("Table {} — no more records. Total chunks: {}", pt.getSourceTable(), chunkNumber);
                break;
            }

            // --- STEP 2: FILTER rows ---
            List<Map<String, Object>> filteredRecords = filterChain.apply(sourceRecords);

            if (filteredRecords.isEmpty()) {
                // All rows filtered out — advance cursor and continue
                lastPkValue = extractLastPk(sourceRecords, pkColumn);
                chunkNumber++;
                continue;
            }

            // --- STEP 3 + 4: TRANSFORM + MAP + WRITE to each target table ---
            for (TargetTableMapping ttm : pt.getTargetTableMappings()) {
                TargetTableContext ttc = ctx.getTargetTableContexts().get(ttm.getId());
                if (ttc == null) {
                    log.warn("No target context for TTM {}, skipping", ttm.getId());
                    continue;
                }

                // Map: source records → target records (with transforms applied)
                ColumnMapperService.BatchMappingResult mappingResult =
                        columnMapperService.mapBatch(filteredRecords, ttc.getColumnMappings());
                List<Map<String, Object>> targetRecords = mappingResult.getTargetRecords();

                // --- STEP 5: BUFFER for live monitor ---
                inFlightBuffer.pushRecords(ctx.getPipelineId(), targetRecords);

                // --- STEP 6: WRITE to target ---
                WriteResult result = writeStrategyExecutor.write(targetConnector, ctx.getTargetConfig(), ttc, targetRecords);

                // Handle write failures
                handleWriteResult(ctx, pt, ttm, result, chunkNumber);
            }

            // --- STEP 7: UPDATE CURSOR ---
            lastPkValue = extractLastPk(sourceRecords, pkColumn);
            long rowsInChunk = filteredRecords.size();
            ctx.incrementRowsProcessed(rowsInChunk);

            // --- STEP 8: SAVE CHECKPOINT ---
            saveCurrentCheckpoint(ctx, pt.getSourceTable(), chunkNumber, lastPkValue);

            // --- STEP 9: PUBLISH PROGRESS ---
            long totalRowsInTable = sourceConnector.getEstimatedRowCount(ctx.getSourceConfig(), pt.getSourceTable());
            publishProgress(ctx, pt, chunkNumber, rowsInChunk, totalRowsInTable, totalRowsAllTables);

            chunkNumber++;
        }
    }

    // =========================================================================
    // WRITE RESULT HANDLING
    // =========================================================================

    private void handleWriteResult(ExecutionContext ctx, PipelineTable pt,
                                    TargetTableMapping ttm, WriteResult result, long chunkNumber) {
        if (result.getFailureCount() == 0) return;

        long errorCount = ctx.incrementErrors(result.getFailureCount());
        boolean ignoreExceptions = ctx.getPipeline().getIgnoreExceptions();
        boolean logSourceRow = ctx.getPipeline().getLogSourceRow();

        for (WriteResult.FailedRecord failed : result.getFailedRecords()) {
            // Publish error event to monitor-service
            ErrorEvent event = ErrorEvent.builder()
                    .pipelineId(ctx.getPipelineId())
                    .executionLogId(ctx.getExecutionLogId())
                    .errorType(resolveErrorType(failed.getErrorType()))
                    .sourceTable(pt.getSourceTable())
                    .targetTable(ttm.getTargetTable())
                    .chunkNumber(chunkNumber)
                    .errorMessage(failed.getErrorMessage())
                    .sourceRowData(logSourceRow ? serializeRecord(failed.getRecord()) : null)
                    .pipelineStopped(!ignoreExceptions)
                    .timestamp(Instant.now())
                    .build();
            kafkaTemplate.send(KafkaTopics.PIPELINE_ERRORS, event);
        }

        // If not ignoring exceptions — stop the pipeline
        if (!ignoreExceptions) {
            throw new DatashifterException(String.format(
                    "Write failed: %d errors on %s → %s at chunk %d. Pipeline stopped (ignoreExceptions=false).",
                    result.getFailureCount(), pt.getSourceTable(), ttm.getTargetTable(), chunkNumber));
        }

        // If ignoring but threshold exceeded — stop
        if (ctx.isErrorThresholdExceeded()) {
            throw new DatashifterException(String.format(
                    "Error threshold exceeded: %d errors (max: %d). Pipeline stopped.",
                    errorCount, ctx.getPipeline().getMaxErrorThreshold()));
        }
    }

    // =========================================================================
    // CONTEXT BUILDER
    // =========================================================================

    private ExecutionContext buildContext(Pipeline pipeline, String executionLogId) {
        Connection sourceConn = connectionRepo.findById(pipeline.getSourceConnectionId())
                .orElseThrow(() -> new ResourceNotFoundException("Source connection", pipeline.getSourceConnectionId()));
        Connection targetConn = connectionRepo.findById(pipeline.getTargetConnectionId())
                .orElseThrow(() -> new ResourceNotFoundException("Target connection", pipeline.getTargetConnectionId()));

        ExecutionContext ctx = ExecutionContext.builder()
                .pipelineId(pipeline.getId())
                .executionLogId(executionLogId)
                .pipeline(pipeline)
                .sourceConfig(toConnectionConfig(sourceConn))
                .targetConfig(toConnectionConfig(targetConn))
                .startedAt(Instant.now())
                .build();

        // Pre-build filter chains and target table contexts
        DatabaseConnector sourceConnector = connectorFactory.getConnector(ctx.getSourceConfig().getDbType());
        DatabaseConnector targetConnector = connectorFactory.getConnector(ctx.getTargetConfig().getDbType());

        for (PipelineTable pt : pipeline.getPipelineTables()) {
            // Build filter chain
            List<RowFilter> filters = pt.getFilters().stream()
                    .sorted(Comparator.comparing(Filter::getFilterOrder))
                    .map(f -> FilterChain.createFilter(f.getColumnName(), f.getOperator(), f.getValue()))
                    .collect(Collectors.toList());
            ctx.getFilterChains().put(pt.getId(), new FilterChain(filters));

            // Build target table contexts via ColumnMappingResolver
            for (TargetTableMapping ttm : pt.getTargetTableMappings()) {
                TargetTableContext ttc = columnMappingResolver.resolve(
                        ttm, sourceConnector, targetConnector,
                        ctx.getSourceConfig(), ctx.getTargetConfig(), pt.getSourceTable());
                columnMappingResolver.validate(ttc);
                writeStrategyExecutor.validateStrategy(ttc); 
                ctx.getTargetTableContexts().put(ttm.getId(), ttc);
            }
        }

        log.info("Context built: {} tables, {} target mappings, {} filter chains",
                pipeline.getPipelineTables().size(),
                ctx.getTargetTableContexts().size(),
                ctx.getFilterChains().size());
        return ctx;
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    private void saveCurrentCheckpoint(ExecutionContext ctx, String tableName,
                                        long chunkNumber, String lastPkValue) {
        checkpointManager.forceCheckpoint(Checkpoint.builder()
                .pipelineId(ctx.getPipelineId())
                .tableName(tableName)
                .currentTableIndex(ctx.getCurrentTableIndex())
                .lastCommittedChunk(chunkNumber)
                .lastCommittedPk(lastPkValue)
                .rowsProcessed(ctx.getTotalRowsProcessed().get())
                .timestamp(Instant.now())
                .build());
    }

    private void publishProgress(ExecutionContext ctx, PipelineTable pt,
                                  long chunkNumber, long rowsInChunk,
                                  long totalRowsInTable, long totalRowsAllTables) {
        ProgressEvent event = ProgressEvent.builder()
                .pipelineId(ctx.getPipelineId())
                .executionLogId(ctx.getExecutionLogId())
                .tableName(pt.getSourceTable())
                .tableIndex(ctx.getCurrentTableIndex())
                .totalTables(ctx.getPipeline().getPipelineTables().size())
                .chunkNumber(chunkNumber)
                .rowsProcessedInChunk(rowsInChunk)
                .totalRowsProcessed(ctx.getTotalRowsProcessed().get())
                .totalRowsInTable(totalRowsInTable)
                .overallProgress(ctx.computeOverallProgress(totalRowsAllTables))
                .rowsPerSec(ctx.computeRowsPerSec())
                .timestamp(Instant.now())
                .build();
        kafkaTemplate.send(KafkaTopics.PIPELINE_PROGRESS, event);
    }

    private void publishStatus(ExecutionContext ctx, PipelineStatus from,
                                PipelineStatus to, String reason) {
        kafkaTemplate.send(KafkaTopics.PIPELINE_STATUS, StatusChangeEvent.builder()
                .pipelineId(ctx.getPipelineId())
                .executionLogId(ctx.getExecutionLogId())
                .previousStatus(from)
                .newStatus(to)
                .reason(reason)
                .timestamp(Instant.now())
                .build());
    }

    private long estimateTotalRows(ExecutionContext ctx, List<PipelineTable> tables) {
        DatabaseConnector sourceConnector = connectorFactory.getConnector(ctx.getSourceConfig().getDbType());
        long total = 0;
        for (PipelineTable pt : tables) {
            total += sourceConnector.getEstimatedRowCount(ctx.getSourceConfig(), pt.getSourceTable());
        }
        return total;
    }

    private String extractLastPk(List<Map<String, Object>> records, String pkColumn) {
        if (records.isEmpty() || pkColumn == null) return null;
        Object lastVal = records.get(records.size() - 1).get(pkColumn);
        return lastVal != null ? lastVal.toString() : null;
    }

    private ConnectionConfig toConnectionConfig(Connection conn) {
        return ConnectionConfig.builder()
                .connectionId(conn.getId())
                .dbType(conn.getDbType())
                .host(conn.getHost())
                .port(conn.getPort())
                .databaseName(conn.getDatabaseName())
                .schemaName(conn.getSchemaName())
                .username(conn.getUsername())
                .password(EncryptionUtil.decrypt(conn.getEncryptedPassword()))
                .build();
    }

    private ErrorType resolveErrorType(String errorType) {
        try {
            return ErrorType.valueOf(errorType);
        } catch (Exception e) {
            return ErrorType.UNKNOWN;
        }
    }

    private String serializeRecord(Map<String, Object> record) {
        try {
            return objectMapper.writeValueAsString(record);
        } catch (Exception e) {
            return record.toString();
        }
    }

    // =========================================================================
    // INTERNAL SIGNAL EXCEPTIONS (flow control, not real errors)
    // =========================================================================

    private static class PipelinePausedException extends RuntimeException {
        PipelinePausedException(String msg) { super(msg); }
    }

    private static class PipelineStoppedException extends RuntimeException {
        PipelineStoppedException(String msg) { super(msg); }
    }
}
