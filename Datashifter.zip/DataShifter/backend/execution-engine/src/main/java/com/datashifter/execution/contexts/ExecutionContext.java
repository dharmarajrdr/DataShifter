package com.datashifter.execution.contexts;

import com.datashifter.common.models.*;
import com.datashifter.connector.spi.interfaces.ConnectionConfig;
import com.datashifter.execution.strategies.filters.FilterChain;
import com.datashifter.execution.strategies.transformers.TransformerChain;
import lombok.*;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Mutable runtime context for a single pipeline execution.
 * Built once at the start of execute(), carried through the entire table loop.
 */
@Getter
@Setter
@Builder
public class ExecutionContext {

    /* --- Identity --- */
    private String pipelineId;
    private String executionLogId;
    private Pipeline pipeline;

    /* --- Connections (decrypted, ready to use) --- */
    private ConnectionConfig sourceConfig;
    private ConnectionConfig targetConfig;

    /* --- Progress counters --- */
    private final AtomicLong totalRowsProcessed = new AtomicLong(0);
    private final AtomicLong totalErrors = new AtomicLong(0);
    private Instant startedAt;

    /* --- Current table state (updated as we iterate tables) --- */
    private int currentTableIndex;
    private String currentTableName;
    private long currentChunkNumber;

    /* --- Pre-built chains per PipelineTable (keyed by pipelineTable.id) --- */
    @Builder.Default
    private Map<String, FilterChain> filterChains = new LinkedHashMap<>();

    /* --- Pre-built column mapping configs per TargetTableMapping (keyed by ttm.id) --- */
    @Builder.Default
    private Map<String, TargetTableContext> targetTableContexts = new LinkedHashMap<>();

    /**
     * Holds resolved mapping + transformer chains for a single target table.
     */
    @Getter @Setter @Builder
    public static class TargetTableContext {
        private String targetTable;
        private String writeMode;
        private String primaryKeyColumn;
        private List<ResolvedColumnMapping> columnMappings;

        /** Source columns that exist but are NOT mapped to any target column (M > N ignored cols) */
        @Builder.Default
        private List<String> unmappedSourceColumns = new ArrayList<>();
    }

    /**
     * One source→target column mapping with its transformer chain resolved.
     *
     * Three scenarios:
     *   1. MAPPED:           sourceColumn != null, mapped = true  → normal mapping
     *   2. UNMAPPED TARGET:  sourceColumn == null, mapped = false → target col has no source; uses defaultValue
     *   3. Source-only cols are NOT in this list — tracked in TargetTableContext.unmappedSourceColumns
     */
    @Getter @Setter @Builder
    public static class ResolvedColumnMapping {
        private String sourceColumn;       // null for unmapped target columns
        private String sourceType;         // e.g., "VARCHAR2", "NUMBER"
        private String targetColumn;
        private String targetType;         // e.g., "INT64", "STRING", "DATE"
        private String defaultValue;       // for unmapped target cols (M < N)
        private boolean nullable;          // whether target column allows null
        private TransformerChain chain;    // null if no transforms

        @Builder.Default
        private boolean mapped = true;     // false for unmapped target columns

        public boolean isUnmappedTarget() {
            return sourceColumn == null || !mapped;
        }
    }

    /* --- Convenience --- */

    public long incrementRowsProcessed(long count) {
        return totalRowsProcessed.addAndGet(count);
    }

    public long incrementErrors(long count) {
        return totalErrors.addAndGet(count);
    }

    public boolean isErrorThresholdExceeded() {
        return totalErrors.get() >= pipeline.getMaxErrorThreshold();
    }

    public double computeOverallProgress(long totalRowsAllTables) {
        if (totalRowsAllTables == 0) return 0.0;
        return Math.min(100.0, (totalRowsProcessed.get() * 100.0) / totalRowsAllTables);
    }

    public long computeRowsPerSec() {
        long elapsed = Math.max(1, Instant.now().toEpochMilli() - startedAt.toEpochMilli());
        return (totalRowsProcessed.get() * 1000) / elapsed;
    }
}