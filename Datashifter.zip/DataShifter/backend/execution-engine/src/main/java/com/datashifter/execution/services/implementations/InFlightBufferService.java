package com.datashifter.execution.services.implementations;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Pushes the latest transformed records into a Redis list (capped at 100).
 * The monitor-service reads this on UI poll to show in-flight records.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class InFlightBufferService {

    private final StringRedisTemplate redisTemplate;
    private final ObjectMapper objectMapper;

    private static final String KEY_PATTERN = "pipeline:%s:inflight";
    private static final long MAX_BUFFER_SIZE = 100;

    /**
     * Push a batch of transformed target records into the buffer.
     * Keeps only the latest 100 records (LIFO — newest at head).
     */
    public void pushRecords(String pipelineId, List<Map<String, Object>> records) {
        if (records == null || records.isEmpty()) return;

        String key = String.format(KEY_PATTERN, pipelineId);
        try {
            for (Map<String, Object> record : records) {
                String json = objectMapper.writeValueAsString(record);
                redisTemplate.opsForList().leftPush(key, json);
            }
            // Trim to keep only latest MAX_BUFFER_SIZE
            redisTemplate.opsForList().trim(key, 0, MAX_BUFFER_SIZE - 1);
        } catch (Exception e) {
            log.warn("Failed to push in-flight records to Redis: {}", e.getMessage());
        }
    }

    /**
     * Clear the in-flight buffer for a pipeline (on completion/error/stop).
     */
    public void clear(String pipelineId) {
        redisTemplate.delete(String.format(KEY_PATTERN, pipelineId));
    }
}
