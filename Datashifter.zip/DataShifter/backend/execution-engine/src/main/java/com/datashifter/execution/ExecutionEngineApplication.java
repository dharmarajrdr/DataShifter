package com.datashifter.execution;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan(basePackages = "com.datashifter.common.models")
public class ExecutionEngineApplication {
    public static void main(String[] args) {
        SpringApplication.run(ExecutionEngineApplication.class, args);
    }
}
