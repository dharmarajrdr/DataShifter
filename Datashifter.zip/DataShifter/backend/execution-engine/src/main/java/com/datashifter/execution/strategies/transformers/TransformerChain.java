package com.datashifter.execution.strategies.transformers;

import lombok.RequiredArgsConstructor;

import java.util.List;

@RequiredArgsConstructor
public class TransformerChain {

    private final List<TransformerStep> steps;

    public Object apply(Object input) {
        Object result = input;
        for (TransformerStep step : steps) {
            result = step.transformer().transform(result, step.arguments());
        }
        return result;
    }

    public record TransformerStep(ColumnTransformer transformer, String arguments) {}
}
