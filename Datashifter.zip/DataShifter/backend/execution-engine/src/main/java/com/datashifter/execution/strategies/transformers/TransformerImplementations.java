package com.datashifter.execution.strategies.transformers;

import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
class TrimTransformer implements ColumnTransformer {
    public Object transform(Object input, String args) { return input == null ? null : input.toString().trim(); }
    public String getFunctionName() { return "TRIM"; }
}

@Component
class ToStringTransformer implements ColumnTransformer {
    public Object transform(Object input, String args) { return input == null ? null : input.toString(); }
    public String getFunctionName() { return "TO_STRING"; }
}

@Component
class ToNumberTransformer implements ColumnTransformer {
    public Object transform(Object input, String args) {
        if (input == null) return null;
        String s = input.toString().trim();
        if (s.contains(".")) return Double.parseDouble(s);
        return Long.parseLong(s);
    }
    public String getFunctionName() { return "TO_NUMBER"; }
}

@Component
class ToDateTransformer implements ColumnTransformer {
    public Object transform(Object input, String args) {
        if (input == null) return null;
        try {
            String pattern = args != null ? args.replace("'", "") : "yyyy-MM-dd";
            return new SimpleDateFormat(pattern).parse(input.toString().trim());
        } catch (Exception e) {
            throw new RuntimeException("TO_DATE failed for value: " + input + " with pattern: " + args, e);
        }
    }
    public String getFunctionName() { return "TO_DATE"; }
}

@Component
class UpperTransformer implements ColumnTransformer {
    public Object transform(Object input, String args) { return input == null ? null : input.toString().toUpperCase(); }
    public String getFunctionName() { return "UPPER"; }
}

@Component
class LowerTransformer implements ColumnTransformer {
    public Object transform(Object input, String args) { return input == null ? null : input.toString().toLowerCase(); }
    public String getFunctionName() { return "LOWER"; }
}

@Component
class DefaultIfNullTransformer implements ColumnTransformer {
    public Object transform(Object input, String args) { return input != null ? input : (args != null ? args.replace("'", "") : ""); }
    public String getFunctionName() { return "DEFAULT_IF_NULL"; }
}

@Component
class ConcatTransformer implements ColumnTransformer {
    public Object transform(Object input, String args) {
        String suffix = args != null ? args.replace("'", "") : "";
        return (input != null ? input.toString() : "") + suffix;
    }
    public String getFunctionName() { return "CONCAT"; }
}

@Component
class SubstringTransformer implements ColumnTransformer {
    public Object transform(Object input, String args) {
        if (input == null) return null;
        String s = input.toString();
        String[] parts = args != null ? args.split(",") : new String[]{"0"};
        int start = Integer.parseInt(parts[0].trim());
        int end = parts.length > 1 ? Integer.parseInt(parts[1].trim()) : s.length();
        return s.substring(Math.min(start, s.length()), Math.min(end, s.length()));
    }
    public String getFunctionName() { return "SUBSTRING"; }
}
