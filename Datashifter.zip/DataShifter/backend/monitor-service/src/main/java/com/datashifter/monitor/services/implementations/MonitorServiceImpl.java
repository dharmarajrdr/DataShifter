package com.datashifter.monitor.services.implementations;

import com.datashifter.common.dtos.MonitorDtos.*;
import com.datashifter.common.enums.ErrorType;
import com.datashifter.common.models.ErrorLog;
import com.datashifter.common.models.ExecutionLog;
import com.datashifter.monitor.repositories.ErrorLogRepository;
import com.datashifter.monitor.repositories.ExecutionLogRepository;
import com.datashifter.monitor.services.interfaces.MonitorService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MonitorServiceImpl implements MonitorService {

    private final ExecutionLogRepository executionLogRepo;
    private final ErrorLogRepository errorLogRepo;
    private final StringRedisTemplate redisTemplate;

    @Override
    public LiveMonitorResponse getLiveMonitor(String pipelineId) {
        // Read live stats from Redis
        String statsKey = "pipeline:" + pipelineId + ":stats";
        Map<Object, Object> stats = redisTemplate.opsForHash().entries(statsKey);

        // Read in-flight records from Redis list
        String inflightKey = "pipeline:" + pipelineId + ":inflight";
        List<String> inflightJson = redisTemplate.opsForList().range(inflightKey, 0, 99);
        List<Map<String, Object>> inflightRecords = new ArrayList<>();
        if (inflightJson != null) {
            for (String json : inflightJson) {
                try {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> record = new com.fasterxml.jackson.databind.ObjectMapper().readValue(json, Map.class);
                    inflightRecords.add(record);
                } catch (Exception e) {
                    // skip malformed records
                }
            }
        }

        return LiveMonitorResponse.builder()
                .pipelineId(pipelineId)
                .pipelineName(getStringFromMap(stats, "pipelineName"))
                .rowsProcessed(getLongFromMap(stats, "rowsProcessed"))
                .rowsPerSec(getLongFromMap(stats, "rowsPerSec"))
                .errorsSkipped(getLongFromMap(stats, "errorsSkipped"))
                .eta(getStringFromMap(stats, "eta"))
                .overallProgress(getDoubleFromMap(stats, "overallProgress"))
                .inflightRecords(inflightRecords)
                .build();
    }

    @Override
    public ErrorSummaryResponse getErrorSummary(String pipelineId, int page, int size) {
        long total = errorLogRepo.countByPipelineId(pipelineId);

        List<Object[]> typeCounts = errorLogRepo.countByErrorType(pipelineId);
        List<ErrorTypeCount> errorsByType = typeCounts.stream()
                .map(row -> ErrorTypeCount.builder()
                        .type((ErrorType) row[0])
                        .count((Long) row[1])
                        .build())
                .collect(Collectors.toList());

        Page<ErrorLog> errorPage = errorLogRepo.findByPipelineId(pipelineId,
                PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt")));

        List<ErrorLogResponse> errors = errorPage.getContent().stream()
                .map(this::toErrorResponse)
                .collect(Collectors.toList());

        return ErrorSummaryResponse.builder()
                .totalErrors(total)
                .errorsByType(errorsByType)
                .errors(errors)
                .build();
    }

    @Override
    public List<ExecutionLogResponse> getExecutionHistory(String pipelineId) {
        return executionLogRepo.findByPipelineIdOrderByStartedAtDesc(pipelineId)
                .stream().map(this::toExecutionResponse).collect(Collectors.toList());
    }

    /* --- Helpers --- */

    private ErrorLogResponse toErrorResponse(ErrorLog e) {
        return ErrorLogResponse.builder()
                .id(e.getId()).errorType(e.getErrorType())
                .sourceTable(e.getSourceTable()).targetTable(e.getTargetTable())
                .chunkNumber(e.getChunkNumber()).rowNumber(e.getRowNumber())
                .errorMessage(e.getErrorMessage()).sourceRowData(e.getSourceRowData())
                .createdAt(e.getCreatedAt()).build();
    }

    private ExecutionLogResponse toExecutionResponse(ExecutionLog e) {
        return ExecutionLogResponse.builder()
                .id(e.getId()).pipelineId(e.getPipelineId()).status(e.getStatus())
                .startedAt(e.getStartedAt()).completedAt(e.getCompletedAt())
                .totalRowsProcessed(e.getTotalRowsProcessed()).totalErrors(e.getTotalErrors())
                .durationMs(e.getDurationMs()).build();
    }

    private String getStringFromMap(Map<Object, Object> map, String key) {
        Object v = map.get(key);
        return v != null ? v.toString() : "";
    }

    private long getLongFromMap(Map<Object, Object> map, String key) {
        Object v = map.get(key);
        if (v == null) return 0L;
        try { return Long.parseLong(v.toString()); } catch (NumberFormatException e) { return 0L; }
    }

    private double getDoubleFromMap(Map<Object, Object> map, String key) {
        Object v = map.get(key);
        if (v == null) return 0.0;
        try { return Double.parseDouble(v.toString()); } catch (NumberFormatException e) { return 0.0; }
    }
}
