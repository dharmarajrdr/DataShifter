package com.datashifter.connector.repositories;

import com.datashifter.common.enums.ConnectionStatus;
import com.datashifter.common.models.Connection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConnectionRepository extends JpaRepository<Connection, String> {
    List<Connection> findByStatus(ConnectionStatus status);
    List<Connection> findByDbType(com.datashifter.common.enums.DatabaseType dbType);
}
