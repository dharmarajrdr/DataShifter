package com.datashifter.connector.services.implementations;

import com.datashifter.common.dtos.ConnectionDtos.*;
import com.datashifter.common.enums.ConnectionStatus;
import com.datashifter.common.exceptions.ResourceNotFoundException;
import com.datashifter.common.models.Connection;
import com.datashifter.common.utils.EncryptionUtil;
import com.datashifter.connector.factories.ConnectorFactory;
import com.datashifter.connector.repositories.ConnectionRepository;
import com.datashifter.connector.services.interfaces.ConnectionService;
import com.datashifter.connector.spi.interfaces.ConnectionConfig;
import com.datashifter.connector.spi.interfaces.DatabaseConnector;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ConnectionServiceImpl implements ConnectionService {

    private final ConnectionRepository repository;
    private final ConnectorFactory connectorFactory;

    @Override
    @Transactional
    public ConnectionResponse create(CreateConnectionRequest request) {
        Connection entity = Connection.builder()
                .name(request.getName())
                .dbType(request.getDbType())
                .dbVersion(request.getDbVersion())
                .host(request.getHost())
                .port(request.getPort())
                .databaseName(request.getDatabaseName())
                .schemaName(request.getSchemaName())
                .username(request.getUsername())
                .encryptedPassword(EncryptionUtil.encrypt(request.getPassword()))
                .extraProperties(request.getExtraProperties())
                .status(ConnectionStatus.TESTING)
                .build();
        entity = repository.save(entity);
        return toResponse(entity);
    }

    @Override
    @Transactional
    public ConnectionResponse update(String id, UpdateConnectionRequest request) {
        Connection entity = findEntity(id);
        if (request.getName() != null) entity.setName(request.getName());
        if (request.getHost() != null) entity.setHost(request.getHost());
        if (request.getPort() != null) entity.setPort(request.getPort());
        if (request.getDatabaseName() != null) entity.setDatabaseName(request.getDatabaseName());
        if (request.getSchemaName() != null) entity.setSchemaName(request.getSchemaName());
        if (request.getUsername() != null) entity.setUsername(request.getUsername());
        if (request.getPassword() != null) entity.setEncryptedPassword(EncryptionUtil.encrypt(request.getPassword()));
        entity = repository.save(entity);
        return toResponse(entity);
    }

    @Override
    public ConnectionResponse getById(String id) {
        return toResponse(findEntity(id));
    }

    @Override
    public List<ConnectionResponse> getAll() {
        return repository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void delete(String id) {
        findEntity(id);
        repository.deleteById(id);
    }

    @Override
    @Transactional
    public TestConnectionResponse testConnection(String id) {
        Connection entity = findEntity(id);
        DatabaseConnector connector = connectorFactory.getConnector(entity.getDbType());
        ConnectionConfig config = buildConfig(entity);
        try {
            long latency = connector.testConnection(config);
            List<String> tables = connector.listTables(config);
            entity.setStatus(ConnectionStatus.CONNECTED);
            entity.setTableCount(tables.size());
            entity.setLastTestedAt(Instant.now());
            entity.setLastError(null);
            repository.save(entity);
            return TestConnectionResponse.builder()
                    .success(true).message("Connected successfully")
                    .tableCount(tables.size()).latencyMs(latency).build();
        } catch (Exception e) {
            entity.setStatus(ConnectionStatus.FAILED);
            entity.setLastTestedAt(Instant.now());
            entity.setLastError(e.getMessage());
            repository.save(entity);
            return TestConnectionResponse.builder()
                    .success(false).message(e.getMessage()).build();
        }
    }

    @Override
    public List<String> listTables(String connectionId) {
        Connection entity = findEntity(connectionId);
        DatabaseConnector connector = connectorFactory.getConnector(entity.getDbType());
        return connector.listTables(buildConfig(entity));
    }

    @Override
    public TableMetadata getTableMetadata(String connectionId, String tableName) {
        Connection entity = findEntity(connectionId);
        DatabaseConnector connector = connectorFactory.getConnector(entity.getDbType());
        return connector.getTableMetadata(buildConfig(entity), tableName);
    }

    @Override
    public List<ForeignKeyMetadata> getForeignKeys(String connectionId, String tableName) {
        Connection entity = findEntity(connectionId);
        DatabaseConnector connector = connectorFactory.getConnector(entity.getDbType());
        return connector.getForeignKeys(buildConfig(entity), tableName);
    }

    /* --- Private helpers --- */

    private Connection findEntity(String id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Connection", id));
    }

    private ConnectionConfig buildConfig(Connection entity) {
        return ConnectionConfig.builder()
                .connectionId(entity.getId())
                .dbType(entity.getDbType())
                .host(entity.getHost())
                .port(entity.getPort())
                .databaseName(entity.getDatabaseName())
                .schemaName(entity.getSchemaName())
                .username(entity.getUsername())
                .password(EncryptionUtil.decrypt(entity.getEncryptedPassword()))
                .build();
    }

    private ConnectionResponse toResponse(Connection e) {
        return ConnectionResponse.builder()
                .id(e.getId()).name(e.getName()).dbType(e.getDbType()).dbVersion(e.getDbVersion())
                .host(e.getHost()).port(e.getPort()).databaseName(e.getDatabaseName())
                .schemaName(e.getSchemaName()).status(e.getStatus()).tableCount(e.getTableCount())
                .lastTestedAt(e.getLastTestedAt()).lastError(e.getLastError()).createdAt(e.getCreatedAt())
                .build();
    }
}
