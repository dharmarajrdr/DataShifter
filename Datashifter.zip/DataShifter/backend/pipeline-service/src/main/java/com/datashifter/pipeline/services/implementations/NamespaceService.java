package com.datashifter.pipeline.services.implementations;

import com.datashifter.common.dtos.NamespaceDtos.*;
import com.datashifter.common.exceptions.DatashifterException;
import com.datashifter.common.exceptions.ResourceNotFoundException;
import com.datashifter.common.models.Namespace;
import com.datashifter.common.models.Pipeline;
import com.datashifter.pipeline.repositories.NamespaceRepository;
import com.datashifter.pipeline.repositories.PipelineRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class NamespaceService {

    private final NamespaceRepository namespaceRepository;
    private final PipelineRepository pipelineRepository;

    private static final String DEFAULT_NS_ID = "ns-default";

    public List<NamespaceResponse> getAll() {
        return namespaceRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    public NamespaceResponse getById(String id) {
        Namespace ns = namespaceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Namespace", id));
        return toResponse(ns);
    }

    @Transactional
    public NamespaceResponse create(CreateNamespaceRequest request) {
        if (namespaceRepository.existsByName(request.getName())) {
            throw new DatashifterException("Namespace already exists: " + request.getName());
        }
        Namespace ns = Namespace.builder()
                .name(request.getName())
                .description(request.getDescription())
                .color(request.getColor() != null ? request.getColor() : "#534AB7")
                .build();
        namespaceRepository.save(ns);
        log.info("Namespace created: {} ({})", ns.getName(), ns.getId());
        return toResponse(ns);
    }

    @Transactional
    public NamespaceResponse update(String id, UpdateNamespaceRequest request) {
        Namespace ns = namespaceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Namespace", id));

        if (request.getName() != null && !request.getName().equals(ns.getName())) {
            if (namespaceRepository.existsByName(request.getName())) {
                throw new DatashifterException("Namespace name already taken: " + request.getName());
            }
            ns.setName(request.getName());
        }
        if (request.getDescription() != null) ns.setDescription(request.getDescription());
        if (request.getColor() != null) ns.setColor(request.getColor());

        namespaceRepository.save(ns);
        return toResponse(ns);
    }

    @Transactional
    public void delete(String id) {
        if (DEFAULT_NS_ID.equals(id)) {
            throw new DatashifterException("Cannot delete the Default namespace");
        }
        Namespace ns = namespaceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Namespace", id));

        // Move all pipelines in this namespace to Default
        List<Pipeline> pipelines = pipelineRepository.findByNamespaceId(id);
        for (Pipeline p : pipelines) {
            p.setNamespaceId(DEFAULT_NS_ID);
        }
        pipelineRepository.saveAll(pipelines);

        namespaceRepository.delete(ns);
        log.info("Namespace deleted: {} — {} pipelines moved to Default", ns.getName(), pipelines.size());
    }

    /**
     * Move a pipeline to a different namespace.
     */
    @Transactional
    public void movePipeline(String pipelineId, String namespaceId) {
        Pipeline pipeline = pipelineRepository.findById(pipelineId)
                .orElseThrow(() -> new ResourceNotFoundException("Pipeline", pipelineId));
        if (!namespaceRepository.existsById(namespaceId)) {
            throw new ResourceNotFoundException("Namespace", namespaceId);
        }
        pipeline.setNamespaceId(namespaceId);
        pipelineRepository.save(pipeline);
        log.info("Pipeline {} moved to namespace {}", pipelineId, namespaceId);
    }

    /**
     * Resolve namespace ID — returns Default if null/blank.
     */
    public String resolveNamespaceId(String namespaceId) {
        if (namespaceId == null || namespaceId.isBlank()) {
            return DEFAULT_NS_ID;
        }
        if (!namespaceRepository.existsById(namespaceId)) {
            throw new ResourceNotFoundException("Namespace", namespaceId);
        }
        return namespaceId;
    }

    /**
     * Get namespace name by ID — used when building PipelineSummaryResponse.
     */
    public String getNamespaceName(String namespaceId) {
        if (namespaceId == null) return "Default";
        return namespaceRepository.findById(namespaceId)
                .map(Namespace::getName)
                .orElse("Default");
    }

    // =========================================================================

    private NamespaceResponse toResponse(Namespace ns) {
        int count = pipelineRepository.findByNamespaceId(ns.getId()).size();
        return NamespaceResponse.builder()
                .id(ns.getId())
                .name(ns.getName())
                .description(ns.getDescription())
                .color(ns.getColor())
                .createdBy(ns.getCreatedBy())
                .pipelineCount(count)
                .createdAt(ns.getCreatedAt())
                .build();
    }
}