package com.datashifter.pipeline.repositories;

import com.datashifter.common.models.Namespace;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface NamespaceRepository extends JpaRepository<Namespace, String> {

    Optional<Namespace> findByName(String name);

    boolean existsByName(String name);

    @Query("SELECT n FROM Namespace n WHERE n.name = 'Default'")
    Optional<Namespace> findDefault();
}