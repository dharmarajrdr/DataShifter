package com.datashifter.pipeline.services.interfaces;

import com.datashifter.common.dtos.PipelineDtos.*;

import java.util.List;

public interface PipelineService {

    PipelineResponse create(CreatePipelineRequest request);

    PipelineResponse update(String id, UpdatePipelineRequest request);

    PipelineResponse getById(String id);

    List<PipelineSummaryResponse> getAll();

    void delete(String id);

    PipelineResponse performAction(String id, PipelineActionRequest action);
}
