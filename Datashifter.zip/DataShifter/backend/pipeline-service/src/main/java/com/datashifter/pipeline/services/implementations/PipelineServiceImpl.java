package com.datashifter.pipeline.services.implementations;

import com.datashifter.common.dtos.PipelineDtos.*;
import com.datashifter.common.enums.PipelineStatus;
import com.datashifter.common.events.KafkaTopics;
import com.datashifter.common.events.PipelineEvents.*;
import com.datashifter.common.exceptions.ResourceNotFoundException;
import com.datashifter.common.models.*;
import com.datashifter.pipeline.repositories.PipelineRepository;
import com.datashifter.pipeline.services.interfaces.PipelineService;
import com.datashifter.pipeline.statemachine.PipelineStateMachine;
import lombok.RequiredArgsConstructor;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PipelineServiceImpl implements PipelineService {

    private final PipelineRepository repository;
    private final KafkaTemplate<String, Object> kafkaTemplate;

    @Override
    @Transactional
    public PipelineResponse create(CreatePipelineRequest req) {
        Pipeline entity = Pipeline.builder()
                .name(req.getName())
                .description(req.getDescription())
                .sourceConnectionId(req.getSourceConnectionId())
                .targetConnectionId(req.getTargetConnectionId())
                .chunkSize(req.getChunkSize() != null ? req.getChunkSize() : 10000)
                .defaultWriteMode(req.getDefaultWriteMode() != null ? req.getDefaultWriteMode() : com.datashifter.common.enums.WriteMode.UPSERT)
                .ignoreExceptions(req.getIgnoreExceptions() != null ? req.getIgnoreExceptions() : false)
                .maxErrorThreshold(req.getMaxErrorThreshold() != null ? req.getMaxErrorThreshold() : 1000)
                .logSourceRow(req.getLogSourceRow() != null ? req.getLogSourceRow() : true)
                .build();

        if (req.getTables() != null) {
            for (PipelineTableRequest tReq : req.getTables()) {
                PipelineTable pt = PipelineTable.builder()
                        .pipeline(entity)
                        .sourceTable(tReq.getSourceTable())
                        .executionOrder(tReq.getExecutionOrder())
                        .mappingType(tReq.getMappingType() != null ? tReq.getMappingType() : com.datashifter.common.enums.TableMappingType.ONE_TO_ONE)
                        .build();
                entity.getPipelineTables().add(pt);
            }
        }
        entity = repository.save(entity);
        return toFullResponse(entity);
    }

    @Override
    @Transactional
    public PipelineResponse update(String id, UpdatePipelineRequest req) {
        Pipeline entity = findEntity(id);
        if (req.getName() != null) entity.setName(req.getName());
        if (req.getDescription() != null) entity.setDescription(req.getDescription());
        if (req.getChunkSize() != null) entity.setChunkSize(req.getChunkSize());
        if (req.getDefaultWriteMode() != null) entity.setDefaultWriteMode(req.getDefaultWriteMode());
        if (req.getIgnoreExceptions() != null) entity.setIgnoreExceptions(req.getIgnoreExceptions());
        if (req.getMaxErrorThreshold() != null) entity.setMaxErrorThreshold(req.getMaxErrorThreshold());
        if (req.getLogSourceRow() != null) entity.setLogSourceRow(req.getLogSourceRow());
        return toFullResponse(repository.save(entity));
    }

    @Override
    public PipelineResponse getById(String id) {
        return toFullResponse(findEntity(id));
    }

    @Override
    public List<PipelineSummaryResponse> getAll() {
        return repository.findAll().stream().map(this::toSummary).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void delete(String id) {
        Pipeline entity = findEntity(id);
        if (entity.getStatus() == PipelineStatus.RUNNING) {
            throw new com.datashifter.common.exceptions.DatashifterException("Cannot delete a running pipeline. Pause or stop it first.");
        }
        repository.deleteById(id);
    }

    @Override
    @Transactional
    public PipelineResponse performAction(String id, PipelineActionRequest action) {
        Pipeline entity = findEntity(id);

        switch (action.getAction()) {
            case VALIDATE:
                PipelineStateMachine.validateTransition(entity.getStatus(), PipelineStatus.VALIDATED);
                entity.setStatus(PipelineStatus.VALIDATED);
                break;

            case START:
            case RESUME:
                PipelineStatus target = PipelineStatus.RUNNING;
                PipelineStateMachine.validateTransition(entity.getStatus(), target);
                entity.setStatus(target);
                repository.save(entity);
                // Publish job event to execution-engine
                kafkaTemplate.send(KafkaTopics.PIPELINE_JOBS,
                        PipelineJobEvent.builder()
                                .pipelineId(id)
                                .action(action.getAction().name())
                                .timestamp(Instant.now())
                                .build());
                break;

            case PAUSE:
                PipelineStateMachine.validateTransition(entity.getStatus(), PipelineStatus.PAUSED);
                kafkaTemplate.send(KafkaTopics.PIPELINE_COMMANDS,
                        PipelineCommandEvent.builder()
                                .pipelineId(id).command("PAUSE").timestamp(Instant.now()).build());
                // Actual state change happens when execution-engine confirms
                break;

            case STOP:
                kafkaTemplate.send(KafkaTopics.PIPELINE_COMMANDS,
                        PipelineCommandEvent.builder()
                                .pipelineId(id).command("STOP").timestamp(Instant.now()).build());
                break;
        }

        return toFullResponse(repository.save(entity));
    }

    /* --- Private helpers --- */

    private Pipeline findEntity(String id) {
        return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Pipeline", id));
    }

    private PipelineResponse toFullResponse(Pipeline e) {
        return PipelineResponse.builder()
                .id(e.getId()).name(e.getName()).description(e.getDescription())
                .sourceConnectionId(e.getSourceConnectionId()).targetConnectionId(e.getTargetConnectionId())
                .status(e.getStatus()).chunkSize(e.getChunkSize()).defaultWriteMode(e.getDefaultWriteMode())
                .ignoreExceptions(e.getIgnoreExceptions()).maxErrorThreshold(e.getMaxErrorThreshold())
                .logSourceRow(e.getLogSourceRow()).createdAt(e.getCreatedAt()).updatedAt(e.getUpdatedAt())
                .build();
    }

    private PipelineSummaryResponse toSummary(Pipeline e) {
        return PipelineSummaryResponse.builder()
                .id(e.getId()).name(e.getName()).status(e.getStatus())
                .tableCount(e.getPipelineTables().size()).createdAt(e.getCreatedAt())
                .build();
    }
}
