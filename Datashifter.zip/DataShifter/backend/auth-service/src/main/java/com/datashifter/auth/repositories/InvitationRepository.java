package com.datashifter.auth.repositories;

import com.datashifter.common.models.Invitation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InvitationRepository extends JpaRepository<Invitation, String> {
    List<Invitation> findByOrgIdAndStatus(String orgId, String status);
    Optional<Invitation> findByToken(String token);
    Optional<Invitation> findByEmailAndOrgIdAndStatus(String email, String orgId, String status);
}
