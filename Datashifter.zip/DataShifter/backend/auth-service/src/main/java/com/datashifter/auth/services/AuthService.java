package com.datashifter.auth.services;

import com.datashifter.auth.repositories.*;
import com.datashifter.common.dtos.AuthDtos.*;
import com.datashifter.common.enums.Permissions;
import com.datashifter.common.exceptions.DatashifterException;
import com.datashifter.common.exceptions.ResourceNotFoundException;
import com.datashifter.common.models.*;
import com.datashifter.common.utils.JwtUtil;
import com.datashifter.common.utils.PermissionResolver;
import com.datashifter.common.utils.PermissionResolver.PermissionOverride;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final UserRepository userRepository;
    private final OrgRepository orgRepository;
    private final RoleRepository roleRepository;
    private final InvitationRepository invitationRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    // =========================================================================
    // SIGNUP — three paths
    // =========================================================================

    /**
     * Path 1: User creates a new org → becomes Admin
     * Path 2: User joins via invite token → assigned invite's role
     * Path 3: User signs up without org → no org yet (can request access later)
     */
    @Transactional
    public TokenResponse signup(SignupRequest request) {
        // Validate email uniqueness
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new DatashifterException("Email already registered: " + request.getEmail());
        }

        String initials = computeInitials(request.getFullName());
        String avatarColor = randomAvatarColor();

        AppUser user = AppUser.builder()
                .email(request.getEmail())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .fullName(request.getFullName())
                .displayInitials(initials)
                .avatarColor(avatarColor)
                .isActive(true)
                .emailVerified(false) // email OTP disabled for now
                .build();

        if (request.getInviteToken() != null && !request.getInviteToken().isBlank()) {
            // PATH 2: Join via invite
            handleInviteSignup(user, request.getInviteToken());
        } else if (request.getOrgName() != null && !request.getOrgName().isBlank()) {
            // PATH 1: Create new org
            handleNewOrgSignup(user, request.getOrgName());
        }
        // PATH 3: No org — user can request access later

        userRepository.save(user);
        log.info("User signed up: {} (org: {})", user.getEmail(), user.getOrgId());

        return generateTokenResponse(user);
    }

    // =========================================================================
    // LOGIN
    // =========================================================================

    @Transactional
    public TokenResponse login(LoginRequest request) {
        AppUser user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new DatashifterException("Invalid email or password"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPasswordHash())) {
            throw new DatashifterException("Invalid email or password");
        }

        if (!user.getIsActive()) {
            throw new DatashifterException("Account is disabled. Contact your org admin.");
        }

        user.setLastLoginAt(Instant.now());
        userRepository.save(user);

        log.info("User logged in: {}", user.getEmail());
        return generateTokenResponse(user);
    }

    // =========================================================================
    // TOKEN REFRESH
    // =========================================================================

    public TokenResponse refreshToken(RefreshTokenRequest request) {
        if (!jwtUtil.isValid(request.getRefreshToken())) {
            throw new DatashifterException("Invalid or expired refresh token");
        }
        if (!"refresh".equals(jwtUtil.getTokenType(request.getRefreshToken()))) {
            throw new DatashifterException("Token is not a refresh token");
        }

        String userId = jwtUtil.getUserId(request.getRefreshToken());
        AppUser user = userRepository.findById(userId)
                .orElseThrow(() -> new DatashifterException("User not found"));

        return generateTokenResponse(user);
    }

    // =========================================================================
    // GET CURRENT USER
    // =========================================================================

    public UserResponse getCurrentUser(String userId) {
        AppUser user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", userId));
        return toUserResponse(user);
    }

    // =========================================================================
    // EFFECTIVE PERMISSIONS
    // =========================================================================

    public Set<String> getEffectivePermissions(AppUser user) {
        if (user.getRoleId() == null) return Set.of();

        Role role = roleRepository.findById(user.getRoleId()).orElse(null);
        if (role == null) return Set.of();

        List<String> rolePerms = role.getPermissions().stream()
                .map(RolePermission::getPermission)
                .toList();

        List<PermissionOverride> overrides = user.getPermissionOverrides().stream()
                .map(up -> new PermissionOverride(up.getPermission(), up.getType()))
                .toList();

        return PermissionResolver.resolve(rolePerms, overrides);
    }

    // =========================================================================
    // PRIVATE — signup paths
    // =========================================================================

    private void handleNewOrgSignup(AppUser user, String orgName) {
        String slug = orgName.toLowerCase()
                .replaceAll("[^a-z0-9]+", "-")
                .replaceAll("^-|-$", "");

        // Ensure unique slug
        String baseSlug = slug;
        int counter = 1;
        while (orgRepository.existsBySlug(slug)) {
            slug = baseSlug + "-" + counter++;
        }

        Organization org = Organization.builder()
                .name(orgName)
                .slug(slug)
                .build();
        orgRepository.save(org);

        // Create default roles for this org
        Role adminRole = seedDefaultRoles(org.getId());

        user.setOrgId(org.getId());
        user.setRoleId(adminRole.getId());

        log.info("New org created: {} (slug: {})", orgName, slug);
    }

    private void handleInviteSignup(AppUser user, String inviteToken) {
        Invitation invite = invitationRepository.findByToken(inviteToken)
                .orElseThrow(() -> new DatashifterException("Invalid invite token"));

        if (!"PENDING".equals(invite.getStatus())) {
            throw new DatashifterException("Invite has already been " + invite.getStatus().toLowerCase());
        }
        if (invite.getExpiresAt() != null && invite.getExpiresAt().isBefore(Instant.now())) {
            invite.setStatus("EXPIRED");
            invitationRepository.save(invite);
            throw new DatashifterException("Invite has expired");
        }

        user.setOrgId(invite.getOrgId());
        user.setRoleId(invite.getRoleId());

        invite.setStatus("ACCEPTED");
        invitationRepository.save(invite);

        log.info("User joined org {} via invite", invite.getOrgId());
    }

    private Role seedDefaultRoles(String orgId) {
        // Admin
        Role admin = Role.builder().orgId(orgId).name("Admin").description("Full access").isSystem(true).build();
        roleRepository.save(admin);
        for (String perm : Permissions.ALL) {
            admin.getPermissions().add(RolePermission.builder().roleId(admin.getId()).permission(perm).build());
        }
        roleRepository.save(admin);

        // Editor
        Role editor = Role.builder().orgId(orgId).name("Editor").description("Create and manage pipelines").isSystem(true).build();
        roleRepository.save(editor);
        for (String perm : Permissions.EDITOR) {
            editor.getPermissions().add(RolePermission.builder().roleId(editor.getId()).permission(perm).build());
        }
        roleRepository.save(editor);

        // Viewer
        Role viewer = Role.builder().orgId(orgId).name("Viewer").description("Read-only access").isSystem(true).build();
        roleRepository.save(viewer);
        for (String perm : Permissions.VIEWER) {
            viewer.getPermissions().add(RolePermission.builder().roleId(viewer.getId()).permission(perm).build());
        }
        roleRepository.save(viewer);

        return admin;
    }

    // =========================================================================
    // PRIVATE — helpers
    // =========================================================================

    private TokenResponse generateTokenResponse(AppUser user) {
        Set<String> perms = getEffectivePermissions(user);
        String roleName = user.getRoleId() != null
                ? roleRepository.findById(user.getRoleId()).map(Role::getName).orElse(null) : null;

        String accessToken = jwtUtil.generateAccessToken(
                user.getId(), user.getEmail(), user.getOrgId(), roleName, perms);
        String refreshToken = jwtUtil.generateRefreshToken(user.getId());

        return TokenResponse.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken)
                .expiresIn(jwtUtil.getAccessTokenExpiryMs() / 1000)
                .tokenType("Bearer")
                .user(toUserResponse(user))
                .build();
    }

    private UserResponse toUserResponse(AppUser user) {
        String orgName = user.getOrgId() != null
                ? orgRepository.findById(user.getOrgId()).map(Organization::getName).orElse(null) : null;
        String roleName = user.getRoleId() != null
                ? roleRepository.findById(user.getRoleId()).map(Role::getName).orElse(null) : null;

        return UserResponse.builder()
                .id(user.getId())
                .email(user.getEmail())
                .fullName(user.getFullName())
                .displayInitials(user.getDisplayInitials())
                .avatarColor(user.getAvatarColor())
                .orgId(user.getOrgId())
                .orgName(orgName)
                .roleId(user.getRoleId())
                .roleName(roleName)
                .effectivePermissions(getEffectivePermissions(user))
                .active(user.getIsActive())
                .emailVerified(user.getEmailVerified())
                .lastLoginAt(user.getLastLoginAt())
                .createdAt(user.getCreatedAt())
                .build();
    }

    private String computeInitials(String fullName) {
        if (fullName == null || fullName.isBlank()) return "?";
        String[] parts = fullName.trim().split("\\s+");
        if (parts.length == 1) return parts[0].substring(0, Math.min(2, parts[0].length())).toUpperCase();
        return (parts[0].charAt(0) + "" + parts[parts.length - 1].charAt(0)).toUpperCase();
    }

    private String randomAvatarColor() {
        String[] colors = {"#534AB7", "#1D9E75", "#D85A30", "#D4537E", "#378ADD", "#639922", "#BA7517"};
        return colors[new Random().nextInt(colors.length)];
    }
}