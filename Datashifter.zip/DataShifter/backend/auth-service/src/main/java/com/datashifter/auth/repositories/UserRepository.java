package com.datashifter.auth.repositories;

import com.datashifter.common.models.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<AppUser, String> {
    Optional<AppUser> findByEmail(String email);
    boolean existsByEmail(String email);
    List<AppUser> findByOrgId(String orgId);
    List<AppUser> findByRoleId(String roleId);
    long countByOrgId(String orgId);
}
