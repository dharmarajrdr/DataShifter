package com.datashifter.common.dtos;

import com.datashifter.common.enums.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.Instant;
import java.util.List;

public class PipelineDtos {
    private PipelineDtos() {}

    /* ---------- Pipeline CRUD ---------- */

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class CreatePipelineRequest {
        @NotBlank private String name;
        private String description;
        private String namespaceId;
        @NotBlank private String sourceConnectionId;
        @NotBlank private String targetConnectionId;
        private Integer chunkSize;
        private WriteMode defaultWriteMode;
        private Boolean ignoreExceptions;
        private Integer maxErrorThreshold;
        private Boolean logSourceRow;
        private List<PipelineTableRequest> tables;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class UpdatePipelineRequest {
        private String name;
        private String description;
        private Integer chunkSize;
        private WriteMode defaultWriteMode;
        private Boolean ignoreExceptions;
        private Integer maxErrorThreshold;
        private Boolean logSourceRow;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class PipelineResponse {
        private String id;
        private String name;
        private String description;
        private String sourceConnectionId;
        private String targetConnectionId;
        private PipelineStatus status;
        private Integer chunkSize;
        private WriteMode defaultWriteMode;
        private Boolean ignoreExceptions;
        private Integer maxErrorThreshold;
        private Boolean logSourceRow;
        private List<PipelineTableResponse> tables;
        private Instant createdAt;
        private Instant updatedAt;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class PipelineSummaryResponse {
        private String id;
        private String name;
        private String namespaceId;
        private String namespaceName;
        private String sourceName;
        private String targetName;
        private PipelineStatus status;
        private int tableCount;
        private double progress;
        private long rowsProcessed;
        private long totalRows;
        private Instant createdAt;

        /** Pipeline creator/owner — populated from auth context in Phase 2 */
        private String ownerName;
        private String ownerInitials;
        private String ownerColor;
    }

    /* ---------- Pipeline Tables ---------- */

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class PipelineTableRequest {
        @NotBlank private String sourceTable;
        @NotNull  private Integer executionOrder;
        private TableMappingType mappingType;
        private List<TargetTableMappingRequest> targetMappings;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class PipelineTableResponse {
        private String id;
        private String sourceTable;
        private Integer executionOrder;
        private TableMappingType mappingType;
        private List<TargetTableMappingResponse> targetMappings;
        private List<FilterResponse> filters;
    }

    /* ---------- Target Table Mappings ---------- */

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class TargetTableMappingRequest {
        @NotBlank private String targetTable;
        private WriteMode writeMode;
        private List<ColumnMappingRequest> columnMappings;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class TargetTableMappingResponse {
        private String id;
        private String targetTable;
        private WriteMode writeMode;
        private List<ColumnMappingResponse> columnMappings;
    }

    /* ---------- Column Mappings ---------- */

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class ColumnMappingRequest {
        @NotBlank private String sourceColumn;
        private String sourceType;
        @NotBlank private String targetColumn;
        private String targetType;
        private Integer mappingOrder;
        private String defaultValue;
        private List<TransformationRequest> transformations;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class ColumnMappingResponse {
        private String id;
        private String sourceColumn;
        private String sourceType;
        private String targetColumn;
        private String targetType;
        private Integer mappingOrder;
        private String defaultValue;
        private List<TransformationResponse> transformations;
    }

    /* ---------- Transformations ---------- */

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class TransformationRequest {
        @NotNull private TransformFunction functionName;
        private String arguments;
        private Integer executionOrder;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class TransformationResponse {
        private String id;
        private TransformFunction functionName;
        private String arguments;
        private Integer executionOrder;
    }

    /* ---------- Filters ---------- */

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class FilterRequest {
        @NotBlank private String columnName;
        @NotNull  private FilterOperator operator;
        private String value;
        private LogicalOperator logicalOperator;
        private Integer filterOrder;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class FilterResponse {
        private String id;
        private String columnName;
        private FilterOperator operator;
        private String value;
        private LogicalOperator logicalOperator;
        private Integer filterOrder;
    }

    /* ---------- Pipeline Actions ---------- */

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class PipelineActionRequest {
        @NotNull private PipelineAction action;
    }

    public enum PipelineAction {
        START, PAUSE, RESUME, STOP, VALIDATE
    }
}