package com.datashifter.common.utils;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Map;
import java.util.Set;

/**
 * JWT utility for token generation and validation.
 *
 * Token claims:
 *   sub   = userId
 *   email = user email
 *   orgId = organization ID
 *   role  = role name
 *   perms = effective permissions (comma-separated)
 *
 * Config in application.properties:
 *   datashifter.jwt.secret=your-256-bit-secret-key-here-change-in-prod
 *   datashifter.jwt.access-token-expiry-ms=900000       (15 min)
 *   datashifter.jwt.refresh-token-expiry-ms=604800000   (7 days)
 */
@Component
public class JwtUtil {

    private final SecretKey key;
    private final long accessTokenExpiryMs;
    private final long refreshTokenExpiryMs;

    public JwtUtil(
            @Value("${datashifter.jwt.secret:datashifter-default-secret-key-change-in-production-env}") String secret,
            @Value("${datashifter.jwt.access-token-expiry-ms:900000}") long accessTokenExpiryMs,
            @Value("${datashifter.jwt.refresh-token-expiry-ms:604800000}") long refreshTokenExpiryMs) {
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.accessTokenExpiryMs = accessTokenExpiryMs;
        this.refreshTokenExpiryMs = refreshTokenExpiryMs;
    }

    /**
     * Generate an access token with user claims.
     */
    public String generateAccessToken(String userId, String email, String orgId,
                                       String roleName, Set<String> permissions) {
        return Jwts.builder()
                .subject(userId)
                .claims(Map.of(
                        "email", email,
                        "orgId", orgId != null ? orgId : "",
                        "role", roleName != null ? roleName : "",
                        "perms", String.join(",", permissions),
                        "type", "access"
                ))
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + accessTokenExpiryMs))
                .signWith(key)
                .compact();
    }

    /**
     * Generate a refresh token (minimal claims).
     */
    public String generateRefreshToken(String userId) {
        return Jwts.builder()
                .subject(userId)
                .claims(Map.of("type", "refresh"))
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + refreshTokenExpiryMs))
                .signWith(key)
                .compact();
    }

    /**
     * Parse and validate a token. Throws on expiry or tampering.
     */
    public Claims parseToken(String token) {
        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public String getUserId(String token) {
        return parseToken(token).getSubject();
    }

    public String getEmail(String token) {
        return parseToken(token).get("email", String.class);
    }

    public String getOrgId(String token) {
        return parseToken(token).get("orgId", String.class);
    }

    public String getRole(String token) {
        return parseToken(token).get("role", String.class);
    }

    public Set<String> getPermissions(String token) {
        String perms = parseToken(token).get("perms", String.class);
        if (perms == null || perms.isBlank()) return Set.of();
        return Set.of(perms.split(","));
    }

    public String getTokenType(String token) {
        return parseToken(token).get("type", String.class);
    }

    public boolean isValid(String token) {
        try {
            parseToken(token);
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            return false;
        }
    }

    public long getAccessTokenExpiryMs() {
        return accessTokenExpiryMs;
    }
}