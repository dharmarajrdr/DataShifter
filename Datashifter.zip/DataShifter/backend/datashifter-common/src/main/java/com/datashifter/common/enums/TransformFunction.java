package com.datashifter.common.enums;

public enum TransformFunction {
    TRIM,
    TO_STRING,
    TO_DATE,
    TO_NUMBER,
    CONCAT,
    SUBSTRING,
    DEFAULT_IF_NULL,
    UPPER,
    LOWER
}
