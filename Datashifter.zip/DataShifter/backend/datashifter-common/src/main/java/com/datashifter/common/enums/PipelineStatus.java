package com.datashifter.common.enums;

public enum PipelineStatus {
    DRAFT,
    VALIDATED,
    RUNNING,
    PAUSED,
    COMPLETED,
    ERRORED
}
